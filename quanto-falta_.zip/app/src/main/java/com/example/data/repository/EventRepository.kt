package com.example.data.repository

import com.example.core.database.EventDao
import com.example.core.database.EventEntity
import com.example.domain.model.Event
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EventRepository(private val eventDao: EventDao) {

    fun getAllEvents(): Flow<List<Event>> {
        return eventDao.getAllEvents().map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    fun getEventById(id: String): Flow<Event?> {
        return eventDao.getEventById(id).map { it?.toDomainModel() }
    }

    suspend fun insertEvent(event: Event) {
        eventDao.insertEvent(event.toEntityModel())
    }

    suspend fun deleteEventById(id: String) {
        eventDao.deleteEventById(id)
    }

    suspend fun markEventAsCompleted(id: String, isCompleted: Boolean) {
        eventDao.updateEventCompletedStatus(id, isCompleted)
    }

    suspend fun markEventAsArchived(id: String, isArchived: Boolean) {
        eventDao.updateEventArchivedStatus(id, isArchived)
    }

    suspend fun deleteAllEvents() {
        eventDao.deleteAllEvents()
    }
}

fun EventEntity.toDomainModel(): Event {
    return Event(
        id = id,
        title = title,
        dateMillis = dateMillis,
        createdAtMillis = createdAtMillis,
        unit = unit,
        color = Color(colorArgb),
        iconName = iconName,
        isCompleted = isCompleted,
        isArchived = isArchived
    )
}

fun Event.toEntityModel(): EventEntity {
    return EventEntity(
        id = id,
        title = title,
        dateMillis = dateMillis,
        createdAtMillis = createdAtMillis,
        unit = unit,
        colorArgb = color.toArgb(),
        iconName = iconName,
        isCompleted = isCompleted,
        isArchived = isArchived
    )
}
