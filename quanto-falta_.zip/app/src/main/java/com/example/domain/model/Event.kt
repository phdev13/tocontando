package com.example.domain.model

import androidx.compose.ui.graphics.Color
import com.example.core.designsystem.theme.Colors

data class Event(
    val id: String,
    val title: String,
    val dateMillis: Long,
    val createdAtMillis: Long,
    val unit: String,
    val color: Color = Colors[0],
    val iconName: String = "Airplane",
    val isCompleted: Boolean = false,
    val isArchived: Boolean = false
)
