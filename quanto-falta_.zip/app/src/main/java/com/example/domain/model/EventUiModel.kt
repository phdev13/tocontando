package com.example.domain.model

import androidx.compose.ui.graphics.Color
import com.example.core.time.TimeUtils
import com.example.core.designsystem.theme.Colors

data class EventUiModel(
    val id: String,
    val title: String,
    val date: String,
    val time: String,
    val units: String,
    val number: String,
    val progress: Float,
    val isSoon: Boolean,
    val color: Color,
    val iconName: String,
    val badgeText: String,
    val totalHoursRemaining: String,
    val isCompleted: Boolean,
    val isArchived: Boolean
)

fun Event.toUiModel(currentMillis: Long = System.currentTimeMillis()): EventUiModel {
    val isDone = isCompleted || currentMillis >= dateMillis
    
    val actualProgress = if (isDone) 1f else TimeUtils.calculateProgress(createdAtMillis, dateMillis, currentMillis)
    val numberStr = if (isDone) "0" else TimeUtils.calculateDifference(dateMillis, currentMillis, unit).toString()
    
    val displayUnit = if (unit.equals("automático", ignoreCase = true) && !isDone) {
        TimeUtils.getAutoUnit(dateMillis, currentMillis)
    } else {
        unit
    }
    
    return EventUiModel(
        id = id,
        title = title,
        date = if (isDone) "Concluído" else TimeUtils.formatDate(dateMillis),
        time = if (isDone) "--:--" else TimeUtils.formatTime(dateMillis),
        units = displayUnit,
        number = numberStr,
        progress = actualProgress,
        isSoon = if (isDone) false else TimeUtils.isSoon(dateMillis, currentMillis),
        color = color,
        iconName = iconName,
        badgeText = if (isDone) "Evento concluído" else TimeUtils.getBadgeText(dateMillis, currentMillis),
        totalHoursRemaining = if (isDone) "0h" else "${TimeUtils.getHoursRemaining(dateMillis, currentMillis)}h",
        isCompleted = isCompleted,
        isArchived = isArchived
    )
}
