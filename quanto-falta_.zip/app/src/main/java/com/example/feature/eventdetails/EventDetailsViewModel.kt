package com.example.feature.eventdetails

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.time.Ticker
import com.example.data.repository.EventRepository
import com.example.domain.model.EventUiModel
import com.example.domain.model.toUiModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class EventDetailsViewModel(private val repository: EventRepository) : ViewModel() {
    private val ticker = Ticker.tickerFlow(1000)
    
    fun getEventUiState(id: String): Flow<EventUiModel?> {
        return combine(repository.getEventById(id), ticker) { event, currentMillis ->
            event?.toUiModel(currentMillis)
        }
    }
    
    fun toggleCompleted(id: String, isCompleted: Boolean) {
        viewModelScope.launch {
            if (!isCompleted) {
                // Reactivating an event
                val event = repository.getEventById(id).firstOrNull()
                if (event != null) {
                    val now = System.currentTimeMillis()
                    if (event.dateMillis <= now) {
                        // Event is in the past. To reactivate its countdown smoothly,
                        // shift its target date to tomorrow (+24 hours) and reset the starting frame.
                        val updatedEvent = event.copy(
                            isCompleted = false,
                            dateMillis = now + 24 * 60 * 60 * 1000,
                            createdAtMillis = now
                        )
                        repository.insertEvent(updatedEvent)
                        return@launch
                    }
                }
            }
            repository.markEventAsCompleted(id, isCompleted)
        }
    }
    
    fun toggleArchived(id: String, isArchived: Boolean) {
        viewModelScope.launch {
            repository.markEventAsArchived(id, isArchived)
        }
    }
    
    fun deleteEvent(id: String) {
        viewModelScope.launch {
            repository.deleteEventById(id)
        }
    }
}
