package com.example.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.EventRepository
import com.example.domain.model.EventUiModel
import com.example.domain.model.toUiModel
import com.example.core.time.Ticker
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(private val repository: EventRepository) : ViewModel() {
    private val ticker = Ticker.tickerFlow(1000)

    val uiState: StateFlow<List<EventUiModel>> = combine(
        repository.getAllEvents(),
        ticker
    ) { events, currentMillis ->
        events
            .filter { !it.isArchived && !it.isCompleted && currentMillis < it.dateMillis }
            .sortedBy { it.dateMillis }
            .map { it.toUiModel(currentMillis) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
