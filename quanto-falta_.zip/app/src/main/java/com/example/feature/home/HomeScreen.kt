package com.example.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.testTag
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import com.example.core.designsystem.theme.AppTypography
import androidx.compose.ui.unit.dp
import com.example.core.designsystem.components.AppBottomNav
import com.example.core.designsystem.components.AppTopBar
import com.example.core.designsystem.components.CompactEventCard
import com.example.core.designsystem.components.MainEventCard
import com.example.core.designsystem.components.EmptyState
import com.example.core.designsystem.components.getIconByName
import androidx.compose.foundation.layout.Box
import com.example.core.designsystem.theme.AppSpacing
import com.example.core.navigation.Screen
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppViewModelProvider
import com.example.core.designsystem.components.fadeSlideIn
import com.example.core.designsystem.components.bounceClick

@Composable
fun HomeScreen(
    onNavigate: (String) -> Unit,
    viewModel: HomeViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val events by viewModel.uiState.collectAsStateWithLifecycle()
    val nextEvent = remember(events) { events.firstOrNull { it.isSoon } ?: events.firstOrNull() }
    val otherEvents = remember(events) { events.filter { it.id != nextEvent?.id } }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Quanto Falta?",
                navigationIcon = {
                    IconButton(onClick = { onNavigate(Screen.More.route) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Configurações")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onNavigate(Screen.CreateEvent.route) },
                        modifier = Modifier
                            .bounceClick { onNavigate(Screen.CreateEvent.route) }
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                shape = androidx.compose.foundation.shape.CircleShape
                            )
                    ) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = "Adicionar evento",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(AppSpacing.small))
                }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentRoute = Screen.Home.route,
                onNavigate = onNavigate
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        if (events.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                EmptyState(
                    icon = getIconByName("Event"),
                    title = "Nenhum evento ativo",
                    description = "Acompanhe seus prazos, viagens ou momentos especiais criados por você.",
                    buttonText = "Criar Meu Primeiro Evento",
                    onButtonClick = { onNavigate(Screen.CreateEvent.route) },
                    testTag = "empty_state_create_button"
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(AppSpacing.medium),
                verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
            ) {
                item(key = "main_event") {
                    nextEvent?.let {
                        MainEventCard(
                            title = it.title,
                            date = it.date,
                            number = it.number,
                            units = it.units,
                            color = it.color,
                            iconName = it.iconName,
                            onClick = { onNavigate(Screen.EventDetails.createRoute(it.id)) },
                            modifier = Modifier.fadeSlideIn(delayMillis = 0)
                        )
                    }
                }

                items(otherEvents, key = { it.id }) { event ->
                    val index = otherEvents.indexOf(event)
                    CompactEventCard(
                        title = event.title,
                        date = event.date,
                        number = event.number,
                        units = event.units,
                        color = event.color,
                        iconName = event.iconName,
                        onClick = { onNavigate(Screen.EventDetails.createRoute(event.id)) },
                        modifier = Modifier.fadeSlideIn(delayMillis = ((index + 1) * 40).coerceAtMost(240))
                    )
                }
                
                // Add some bottom spacing so the last item isn't strictly hugging the bottom nav
                item { Spacer(modifier = Modifier.padding(bottom = 24.dp)) }
            }
        }
    }
}
