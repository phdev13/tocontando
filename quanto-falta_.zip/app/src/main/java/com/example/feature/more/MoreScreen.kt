package com.example.feature.more

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.AppViewModelProvider
import com.example.core.designsystem.components.AppBottomNav
import com.example.core.designsystem.components.AppTopBar
import com.example.core.designsystem.theme.AppSpacing
import com.example.core.designsystem.theme.AppTypography
import com.example.core.navigation.Screen
import com.example.core.designsystem.components.WidgetsPreviewSelector
import com.example.core.designsystem.components.fadeSlideIn
import com.example.core.designsystem.components.bounceClick
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType

@Composable
fun MoreScreen(
    onNavigate: (String) -> Unit,
    viewModel: MoreViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showClearDialog by remember { mutableStateOf(false) }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Apagar Todos os Eventos?", style = AppTypography.titleLarge) },
            text = { Text("Tem certeza de que deseja excluir permanentemente todos os eventos? Isso limpará totalmente o banco de dados local.", style = AppTypography.bodyMedium) },
            confirmButton = {
                val haptic = LocalHapticFeedback.current
                TextButton(
                    onClick = {
                        try {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        } catch (e: Exception) {}
                        viewModel.clearAllData()
                        showClearDialog = false
                    },
                    modifier = Modifier.testTag("confirm_clear_db_button")
                ) {
                    Text("Sim, Apagar Tudo", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Ajustes & Dados",
                navigationIcon = {
                    IconButton(onClick = { onNavigate(Screen.Home.route) }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentRoute = Screen.More.route,
                onNavigate = onNavigate
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .fadeSlideIn(),
            contentPadding = PaddingValues(AppSpacing.medium),
            verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
        ) {
            // Header Section
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = AppSpacing.medium),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Settings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(AppSpacing.medium))
                        Text(
                            text = "Quanto Falta?",
                            style = AppTypography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Versão 1.0.0 • Banco de Dados Local Ativo",
                            style = AppTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            // Configuração do Tema do Aplicativo
            item {
                val currentTheme by viewModel.themeState.collectAsStateWithLifecycle()
                AppThemeSelector(
                    currentTheme = currentTheme,
                    onThemeSelected = { viewModel.selectTheme(it) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Stat Cards Grid Section
            item {
                Text(
                    text = "Estatísticas do Banco de Dados",
                    style = AppTypography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = AppSpacing.small)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(AppSpacing.small)
                ) {
                    StatCard(
                        title = "Ativos",
                        value = uiState.activeEvents.toString(),
                        icon = Icons.Filled.DateRange,
                        iconColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Concluídos",
                        value = uiState.completedEvents.toString(),
                        icon = Icons.Filled.CheckCircle,
                        iconColor = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
                
                Spacer(modifier = Modifier.height(AppSpacing.small))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(AppSpacing.small)
                ) {
                    StatCard(
                        title = "Arquivados",
                        value = uiState.archivedEvents.toString(),
                        icon = Icons.Filled.Archive,
                        iconColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Total Geral",
                        value = uiState.totalEvents.toString(),
                        icon = Icons.Filled.ListAlt,
                        iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Widgets & Temas Display Section (Faithful to reference image)
            item {
                Spacer(modifier = Modifier.height(AppSpacing.medium))
                
                Text(
                    text = "Aparência dos Widgets & Temas",
                    style = AppTypography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = AppSpacing.small)
                )
                
                WidgetsPreviewSelector(
                    allEvents = uiState.eventsList,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Database and Data Management Section
            item {
                Spacer(modifier = Modifier.height(AppSpacing.medium))
                
                Text(
                    text = "Gerenciamento de Dados",
                    style = AppTypography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = AppSpacing.small)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(AppSpacing.small)
                ) {
                    // Clear Database Option
                    ActionItemCard(
                        title = "Limpar Todo o Banco de Dados",
                        description = "Exclui permanentemente todos os eventos ativos, arquivados e concluídos.",
                        icon = Icons.Filled.DeleteSweep,
                        iconColor = MaterialTheme.colorScheme.error,
                        testTag = "clear_all_events_button",
                        onClick = { showClearDialog = true }
                    )

                    // Onboarding option
                    ActionItemCard(
                        title = "Rever Introdução Interativa",
                        description = "Inicia a introdução guiada de 3 etapas para rever as principais propostas do app.",
                        icon = Icons.Filled.RestartAlt,
                        iconColor = MaterialTheme.colorScheme.primary,
                        testTag = "reset_intro_button",
                        onClick = {
                            viewModel.resetIntro()
                            onNavigate(Screen.Intro.route)
                        }
                    )
                }
            }

            // About of app
            item {
                Spacer(modifier = Modifier.height(AppSpacing.medium))
                
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(AppSpacing.medium),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(AppSpacing.medium))
                        Text(
                            text = "O aplicativo armazena todos os seus dados com segurança offline neste dispositivo Android através de criptografia local em SQLite.",
                            style = AppTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(AppSpacing.medium)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = AppTypography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(AppSpacing.small))
            Text(
                text = value,
                style = AppTypography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

@Composable
fun ActionItemCard(
    title: String,
    description: String,
    icon: ImageVector,
    iconColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
            .bounceClick(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(AppSpacing.medium),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(AppSpacing.medium))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = AppTypography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = AppTypography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}

@Composable
fun AppThemeSelector(
    currentTheme: String,
    onThemeSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp)
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(AppSpacing.medium),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "TEMA DO APLICATIVO",
            style = AppTypography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            ),
            color = MaterialTheme.colorScheme.primary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(AppSpacing.small)
        ) {
            val options = listOf(
                Triple("system", "Sistema", Icons.Filled.Settings),
                Triple("light", "Claro", Icons.Filled.WbSunny),
                Triple("dark", "Escuro", Icons.Filled.NightsStay)
            )

            options.forEach { (themeKey, name, icon) ->
                val isSelected = currentTheme == themeKey
                
                val bgSelectedColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                val bgUnselectedColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                val cardBg = if (isSelected) bgSelectedColor else bgUnselectedColor
                val borderCol = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                val contentCol = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(86.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(cardBg)
                        .border(1.5.dp, borderCol, RoundedCornerShape(12.dp))
                        .clickable {
                            try {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            } catch (e: Exception) {}
                            onThemeSelected(themeKey)
                        }
                        .padding(AppSpacing.small),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = name,
                            tint = contentCol,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = name,
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
