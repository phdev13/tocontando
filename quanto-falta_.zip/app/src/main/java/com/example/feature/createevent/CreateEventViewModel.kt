package com.example.feature.createevent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.EventRepository
import com.example.domain.model.Event
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.UUID

class CreateEventViewModel(private val repository: EventRepository) : ViewModel() {
    
    suspend fun getEvent(id: String): Event? {
        return repository.getEventById(id).firstOrNull()
    }
    
    fun saveEvent(
        id: String?,
        title: String,
        dateMillis: Long,
        unit: String,
        colorArgb: Int,
        iconName: String
    ) {
        viewModelScope.launch {
            val existing = id?.let { repository.getEventById(it).firstOrNull() }
            
            val event = Event(
                id = id ?: UUID.randomUUID().toString(),
                title = title.trim(),
                dateMillis = dateMillis,
                createdAtMillis = existing?.createdAtMillis ?: System.currentTimeMillis(),
                unit = unit,
                color = androidx.compose.ui.graphics.Color(colorArgb),
                iconName = iconName,
                isCompleted = existing?.isCompleted ?: false,
                isArchived = existing?.isArchived ?: false
            )
            repository.insertEvent(event)
        }
    }
}
