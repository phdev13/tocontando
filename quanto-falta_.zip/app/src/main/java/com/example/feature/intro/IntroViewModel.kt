package com.example.feature.intro

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.preferences.IntroManager
import kotlinx.coroutines.launch

class IntroViewModel(
    private val introManager: IntroManager
) : ViewModel() {

    fun completeIntro() {
        viewModelScope.launch {
            introManager.setIntroCompleted(true)
        }
    }
}
