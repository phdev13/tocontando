package com.example.feature.eventdetails

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import com.example.core.designsystem.components.fadeSlideIn
import com.example.core.designsystem.components.AppTopBar
import com.example.core.designsystem.components.getIconByName
import com.example.core.designsystem.theme.AppShapes
import com.example.core.designsystem.theme.AppSpacing
import com.example.core.designsystem.theme.AppTypography
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.navigation.Screen
import com.example.core.AppViewModelProvider
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Check

@Composable
fun EventDetailsScreen(
    eventId: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: EventDetailsViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val uiStateEvent by remember(eventId) { viewModel.getEventUiState(eventId) }.collectAsStateWithLifecycle(null)
    val event = uiStateEvent
    val haptic = LocalHapticFeedback.current
    
    if (event == null) {
        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        return
    }
    
    var showDeleteDialog by remember { mutableStateOf(false) }
    
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Excluir evento") },
            text = { Text("Tem certeza que deseja excluir '${event.title}' permanentemente? Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    } catch (e: Exception) {}
                    showDeleteDialog = false
                    viewModel.deleteEvent(eventId)
                    onBack()
                }) {
                    Text("Excluir", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "",
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigate(Screen.CreateEvent.createRoute(eventId)) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Editar")
                    }
                    IconButton(onClick = {
                        try {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        } catch (e: Exception) {}
                        viewModel.toggleArchived(eventId, !event.isArchived)
                    }) {
                        Icon(if (event.isArchived) Icons.Filled.Unarchive else Icons.Filled.Archive, contentDescription = if (event.isArchived) "Desarquivar" else "Arquivar")
                    }
                    IconButton(onClick = {
                        try {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        } catch (e: Exception) {}
                        viewModel.toggleCompleted(eventId, !event.isCompleted)
                    }) {
                        Icon(if (event.isCompleted) Icons.Filled.RestartAlt else Icons.Filled.Check, contentDescription = if (event.isCompleted) "Reativar" else "Concluir")
                    }
                    IconButton(onClick = {
                        showDeleteDialog = true
                    }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Deletar")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = AppSpacing.large)
                .fadeSlideIn()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(AppSpacing.medium))
            
            // Icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(event.color),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getIconByName(event.iconName),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(AppSpacing.mediumLarge))
            
            // Title and Date
            Text(
                text = event.title,
                style = AppTypography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(AppSpacing.extraSmall))
            Text(
                text = "${event.date} às ${event.time}",
                style = AppTypography.bodyMedium,
                color = MaterialTheme.colorScheme.outline
            )
            
            Spacer(modifier = Modifier.height(AppSpacing.huge))
            
            // Main Countdown
            Text(
                text = event.number,
                style = AppTypography.displayLarge.copy(fontFeatureSettings = "tnum"),
                color = event.color
            )
            Text(
                text = event.units,
                style = AppTypography.headlineMedium,
                color = event.color
            )
            
            Spacer(modifier = Modifier.height(AppSpacing.mediumLarge))
            
            // Badge
            Box(
                modifier = Modifier
                    .clip(AppShapes.pill)
                    .background(event.color.copy(alpha = 0.1f))
                    .padding(horizontal = AppSpacing.medium, vertical = AppSpacing.small)
            ) {
                Text(
                    text = event.badgeText,
                    style = AppTypography.labelLarge,
                    color = event.color
                )
            }
            
            Spacer(modifier = Modifier.height(AppSpacing.extraLarge))
            
            // Progress Bar
            val animatedProgress by animateFloatAsState(
                targetValue = event.progress,
                animationSpec = tween(500, easing = FastOutSlowInEasing),
                label = "eventDetailsProgress"
            )
            
            Text(
                text = "${(event.progress * 100).toInt()}% concluído",
                style = AppTypography.labelLarge,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(AppSpacing.small))
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(AppShapes.pill),
                color = event.color,
                trackColor = event.color.copy(alpha = 0.2f),
                strokeCap = StrokeCap.Round
            )
            
            Spacer(modifier = Modifier.height(AppSpacing.extraLarge))
            
            // Info Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(AppSpacing.medium)
            ) {
                // Time Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = AppShapes.medium,
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(AppSpacing.medium),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Horas restantes",
                            style = AppTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(AppSpacing.small))
                        Text(
                            text = event.totalHoursRemaining,
                            style = AppTypography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                
                // Progress Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = AppShapes.medium,
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(AppSpacing.medium),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Progresso total",
                            style = AppTypography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(AppSpacing.small))
                        Text(
                            text = "${(event.progress * 100).toInt()}%",
                            style = AppTypography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(AppSpacing.extraLarge))
            
            // Bottom Info Message
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(AppShapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(AppSpacing.large),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getPromoMessage(event.iconName, event.title, event.isCompleted),
                    style = AppTypography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.height(AppSpacing.large))
        }
    }
}

fun getPromoMessage(iconName: String, title: String, isCompleted: Boolean): String {
    if (isCompleted) {
        return "Este momento especial chegou! Esperamos que tenha rendido memórias incríveis. 🎉🌟"
    }
    return when (iconName) {
        "Airplane", "FlightTakeoff" -> "Prepare as malas! A sua contagem regressiva para viajar está quase no fim. ✈️🌎"
        "Cake" -> "O dia de celebrar a vida e soprar as velinhas está chegando! Prepare o parabéns! 🎂🎉"
        "BeachAccess" -> "A contagem para relaxar e aproveitar o sol está valendo! Recarregue suas energias. 🏖️☀️"
        "AttachMoney" -> "Seu planejamento financeiro e metas se aproximam a cada segundo! Foco! 💰📈"
        "MusicNote" -> "A sintonia perfeita e ótimas vibrações musicais estão vindo aí! 🎵🎧"
        "SportsEsports" -> "Prepare o controle e aqueça os motores, a contagem para o jogo está ativa! 🎮🔥"
        "LocalCafe" -> "Aquele papo amigável e um café quentinho estão mais perto do que imagina! ☕️❤️"
        "Work" -> "Seu próximo grande projeto ou entrega profissional está a caminho! Sucesso! 💼🚀"
        else -> "Falta pouco para que este momento especial aconteça! Aproveite cada instante. ✨"
    }
}
