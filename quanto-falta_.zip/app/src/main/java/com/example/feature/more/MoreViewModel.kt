package com.example.feature.more

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.EventRepository
import com.example.domain.model.Event
import com.example.core.designsystem.theme.ThemeManager
import com.example.core.preferences.IntroManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MoreUiState(
    val totalEvents: Int = 0,
    val activeEvents: Int = 0,
    val completedEvents: Int = 0,
    val archivedEvents: Int = 0,
    val eventsList: List<Event> = emptyList()
)

class MoreViewModel(
    private val repository: EventRepository,
    private val themeManager: ThemeManager,
    private val introManager: IntroManager
) : ViewModel() {

    val themeState: StateFlow<String> = themeManager.themeState

    val uiState: StateFlow<MoreUiState> = repository.getAllEvents().map { events ->
        val now = System.currentTimeMillis()
        MoreUiState(
            totalEvents = events.size,
            activeEvents = events.count { !it.isArchived && !it.isCompleted && now < it.dateMillis },
            completedEvents = events.count { (it.isCompleted || now >= it.dateMillis) && !it.isArchived },
            archivedEvents = events.count { it.isArchived },
            eventsList = events.filter { !it.isArchived }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MoreUiState()
    )

    fun selectTheme(theme: String) {
        themeManager.setThemePreference(theme)
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.deleteAllEvents()
        }
    }

    fun resetIntro() {
        viewModelScope.launch {
            introManager.setIntroCompleted(false)
        }
    }
}
