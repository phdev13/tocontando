package com.example.feature.highlight

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.time.Ticker
import com.example.data.repository.EventRepository
import com.example.domain.model.EventUiModel
import com.example.domain.model.toUiModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

sealed interface HighlightUiState {
    object Loading : HighlightUiState
    data class Success(val event: EventUiModel) : HighlightUiState
    object Empty : HighlightUiState
}

class HighlightViewModel(private val repository: EventRepository) : ViewModel() {
    private val ticker = Ticker.tickerFlow(1000)
    
    fun getHighlightUiState(id: String): StateFlow<HighlightUiState> {
        val eventFlow = if (id == "1" || id.isBlank()) {
            repository.getAllEvents().map { events -> 
                val now = System.currentTimeMillis()
                events.filter { !it.isArchived && !it.isCompleted && it.dateMillis > now }.minByOrNull { it.dateMillis } 
            }
        } else {
            repository.getEventById(id)
        }
        
        return combine(eventFlow, ticker) { event, currentMillis ->
            if (event != null) {
                HighlightUiState.Success(event.toUiModel(currentMillis))
            } else {
                HighlightUiState.Empty
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HighlightUiState.Loading
        )
    }
}
