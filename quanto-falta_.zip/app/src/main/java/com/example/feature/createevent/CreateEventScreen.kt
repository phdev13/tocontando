package com.example.feature.createevent

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.graphicsLayer
import com.example.core.designsystem.components.bounceClick
import com.example.core.designsystem.components.fadeSlideIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import com.example.core.designsystem.components.AppTextField
import com.example.core.designsystem.components.AppTopBar
import com.example.core.designsystem.components.getIconByName
import com.example.core.designsystem.components.getIconDisplayName
import com.example.core.designsystem.components.iconNamesList
import com.example.core.designsystem.theme.AppShapes
import com.example.core.designsystem.theme.AppSpacing
import com.example.core.designsystem.theme.AppTypography
import com.example.core.designsystem.theme.Colors

import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.AppViewModelProvider
import com.example.core.time.TimeUtils
import androidx.compose.ui.graphics.toArgb
import com.example.core.designsystem.components.showDatePicker
import com.example.core.designsystem.components.showTimePicker

// Localized Color Names MAP (Issue 8)
private val ColorLabelMap = mapOf(
    Color(0xFF7B61FF) to "Lilás Real",
    Color(0xFF4A90FF) to "Azul Celeste",
    Color(0xFF34C759) to "Verde Esmeralda",
    Color(0xFFFF9F0A) to "Abóbora / Laranja",
    Color(0xFFFF453A) to "Cereja / Vermelho",
    Color(0xFFFF375F) to "Rosa Choque",
    Color(0xFF32ADE6) to "Ciano Neon"
)

private fun getColorLabel(color: Color): String {
    return ColorLabelMap[color] ?: "Cor customizada"
}

@Composable
fun CreateEventScreen(
    eventId: String? = null,
    prefillTitle: String? = null,
    prefillColorHex: String? = null,
    prefillIconName: String? = null,
    prefillDaysLeft: Int? = null,
    onBack: () -> Unit,
    viewModel: CreateEventViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val initialTitle = prefillTitle ?: ""
    val initialColor = remember(prefillColorHex) {
        prefillColorHex?.let {
            try {
                Color(android.graphics.Color.parseColor(it))
            } catch (e: Exception) {
                null
            }
        } ?: Colors[0]
    }
    val initialIcon = prefillIconName ?: iconNamesList[0]
    val initialTimestamp = remember(prefillDaysLeft) {
        prefillDaysLeft?.let {
            System.currentTimeMillis() + it.toLong() * 24L * 60L * 60L * 1000L
        } ?: (System.currentTimeMillis() + 24 * 60 * 60 * 1000)
    }

    var name by remember { mutableStateOf(initialTitle) }
    var selectedColor by remember { mutableStateOf(initialColor) }
    var selectedIcon by remember { mutableStateOf(initialIcon) }
    var timestamp by remember { mutableStateOf(initialTimestamp) }
    var unit by remember { mutableStateOf("Automático") }
    
    // Dialog state controllers
    var showFullIconPicker by remember { mutableStateOf(false) }
    var showUnitPicker by remember { mutableStateOf(false) }

    val context = LocalContext.current
    var isSaving by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    
    LaunchedEffect(eventId) {
        if (eventId != null) {
            val event = viewModel.getEvent(eventId)
            if (event != null) {
                name = event.title
                selectedColor = event.color
                selectedIcon = event.iconName
                timestamp = event.dateMillis
                unit = event.unit
            }
        }
    }
    
    Scaffold(
        topBar = {
            AppTopBar(
                title = if (eventId == null) "Novo evento" else "Editar evento",
                centerTitle = true,
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.Close, contentDescription = "Fechar")
                    }
                },
                actions = {
                    val isValid = name.isNotBlank()
                    Button(
                        onClick = {
                            if (isValid && !isSaving) {
                                isSaving = true
                                try {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                } catch (e: Exception) {}
                                viewModel.saveEvent(
                                    id = eventId,
                                    title = name,
                                    dateMillis = timestamp,
                                    unit = unit,
                                    colorArgb = selectedColor.toArgb(),
                                    iconName = selectedIcon
                                )
                                onBack()
                            }
                        },
                        enabled = isValid,
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            disabledContainerColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                            disabledContentColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        ),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        contentPadding = PaddingValues(horizontal = AppSpacing.medium, vertical = 0.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .padding(end = AppSpacing.small)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Salvar",
                            style = AppTypography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .fadeSlideIn()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = AppSpacing.medium)
                    .padding(top = AppSpacing.small),
                verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
            ) {
                // SEÇÃO 1: INFORMAÇÕES BÁSICAS
                FormSection(title = "Informações básicas") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "NOME DO EVENTO",
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        AppTextField(
                            value = name,
                            onValueChange = { name = it },
                            placeholder = "Viagem para Salvador",
                            icon = getIconByName("Create")
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "UNIDADE DE CONTAGEM",
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        AppTextField(
                            value = unit,
                            onValueChange = {},
                            placeholder = "Dias",
                            icon = getIconByName("List"),
                            onClick = { showUnitPicker = true }
                        )
                    }
                }

                // SEÇÃO 2: DATA E HORÁRIO
                FormSection(title = "Data e horário") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "DATA",
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        AppTextField(
                            value = TimeUtils.formatDate(timestamp),
                            onValueChange = {},
                            placeholder = "24 de maio de 2024",
                            icon = getIconByName("Event"),
                            onClick = {
                                showDatePicker(context) { newDate -> timestamp = newDate }
                            }
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "HORÁRIO",
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        AppTextField(
                            value = TimeUtils.formatTime(timestamp),
                            onValueChange = {},
                            placeholder = "09:00",
                            icon = getIconByName("Alarm"),
                            onClick = {
                                showTimePicker(context, timestamp) { newTime -> timestamp = newTime }
                            }
                        )
                    }
                }

                // SEÇÃO 3: APARÊNCIA
                FormSection(title = "Aparência") {
                    // Preview do Ícone e Nome Ativo (Hierarquia Real)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f),
                                shape = AppShapes.medium
                            )
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                shape = AppShapes.medium
                            )
                            .padding(AppSpacing.medium),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(AppSpacing.medium)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(AppShapes.medium)
                                .background(selectedColor.copy(alpha = 0.15f))
                                .border(2.dp, selectedColor, AppShapes.medium),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getIconByName(selectedIcon),
                                contentDescription = null,
                                modifier = Modifier.size(28.dp),
                                tint = selectedColor
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "ÍCONE SELECIONADO",
                                style = AppTypography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.outline
                            )
                            Text(
                                text = getIconDisplayName(selectedIcon),
                                style = AppTypography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Seletor de cores
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "COR DO EVENTO",
                                style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Text(
                                text = getColorLabel(selectedColor),
                                style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = selectedColor
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Colors.forEach { color ->
                                val isSelected = selectedColor == color
                                val scaleFactor by animateFloatAsState(
                                    targetValue = if (isSelected) 1.2f else 1.0f,
                                    animationSpec = tween(120),
                                    label = "scale"
                                )
                                val borderAlpha by animateFloatAsState(
                                    targetValue = if (isSelected) 0.6f else 0.0f,
                                    animationSpec = tween(120),
                                    label = "border"
                                )

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .graphicsLayer {
                                            scaleX = scaleFactor
                                            scaleY = scaleFactor
                                        }
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = 3.dp,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = borderAlpha),
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            try {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            } catch (e: Exception) {}
                                            selectedColor = color
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Seletor de ícones recomendados
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "RECOMENDADOS",
                            style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )

                        val popularIcons = listOf("Airplane", "Cake", "BeachAccess", "MusicNote", "Alarm", "Favorite", "Work", "School")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            popularIcons.forEach { iconName ->
                                val isSelected = selectedIcon == iconName
                                val iconScale by animateFloatAsState(
                                    targetValue = if (isSelected) 1.15f else 1.0f,
                                    animationSpec = tween(120),
                                    label = "pIconScale"
                                )
                                val iconBg by animateColorAsState(
                                    targetValue = if (isSelected) selectedColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    animationSpec = tween(120),
                                    label = "pIconBg"
                                )
                                val iconBorderColor by animateColorAsState(
                                    targetValue = if (isSelected) selectedColor else Color.Transparent,
                                    animationSpec = tween(120),
                                    label = "pIconBorder"
                                )

                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .graphicsLayer {
                                            scaleX = iconScale
                                            scaleY = iconScale
                                        }
                                        .clip(AppShapes.small)
                                        .background(iconBg)
                                        .border(1.5.dp, iconBorderColor, AppShapes.small)
                                        .clickable {
                                            try {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            } catch (e: Exception) {}
                                            selectedIcon = iconName
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = getIconByName(iconName),
                                        contentDescription = getIconDisplayName(iconName),
                                        modifier = Modifier.size(20.dp),
                                        tint = if (isSelected) selectedColor else MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }

                        // Pesquisa global de ícones acionadora
                        TextButton(
                            onClick = { showFullIconPicker = true },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Pesquisar mais ícones...",
                                style = AppTypography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Info box at any bottom layout with proper system bar padding
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = AppSpacing.medium)
                    .clip(AppShapes.medium)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f))
                    .padding(AppSpacing.medium),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "A contagem de tempo do seu evento iniciará imediatamente após salvar.",
                    style = AppTypography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.navigationBarsPadding())
            Spacer(modifier = Modifier.height(AppSpacing.mediumLarge))
        }
    }

    // Modal dialogs
    if (showFullIconPicker) {
        IconPickerDialog(
            currentSelection = selectedIcon,
            onIconSelected = { selectedIcon = it },
            onDismiss = { showFullIconPicker = false }
        )
    }

    if (showUnitPicker) {
        UnitPickerDialog(
            currentUnit = unit,
            onUnitSelected = { unit = it },
            onDismiss = { showUnitPicker = false }
        )
    }
}

@Composable
private fun FormSection(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.surface,
                shape = AppShapes.large
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f),
                shape = AppShapes.large
            )
            .padding(AppSpacing.medium),
        verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
    ) {
        Text(
            text = title.uppercase(),
            style = AppTypography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            ),
            color = MaterialTheme.colorScheme.primary
        )
        content()
    }
}

// ICON PICKER DIALOG (Issues 4, 5, 6, 7 & 12 resolved)
@Composable
fun IconPickerDialog(
    currentSelection: String,
    onIconSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredNames = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            iconNamesList
        } else {
            iconNamesList.filter { name ->
                name.contains(searchQuery, ignoreCase = true) ||
                getIconDisplayName(name).contains(searchQuery, ignoreCase = true)
            }
        }
    }
    
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .height(550.dp),
            shape = AppShapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(AppSpacing.medium),
                verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pesquisar Ícone",
                        style = AppTypography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Fechar")
                    }
                }
                
                // Clear fully visible single-line Box Search input
                AppTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = "Pesquisar (ex: avião, bolo, música)...",
                    icon = Icons.Filled.Search
                )
                
                Box(modifier = Modifier.weight(1f)) {
                    if (filteredNames.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Nenhum ícone correspondente",
                                style = AppTypography.bodyMedium,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 68.dp),
                            verticalArrangement = Arrangement.spacedBy(AppSpacing.small),
                            horizontalArrangement = Arrangement.spacedBy(AppSpacing.small),
                            contentPadding = PaddingValues(bottom = AppSpacing.medium)
                        ) {
                            items(filteredNames) { name ->
                                val isSelected = currentSelection == name
                                val displayName = getIconDisplayName(name)
                                val bg by animateColorAsState(
                                    targetValue = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent,
                                    label = "cellBg"
                                )
                                val borderCol by animateColorAsState(
                                    targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    label = "cellBorder"
                                )
                                
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .clip(AppShapes.medium)
                                        .background(bg)
                                        .border(1.5.dp, borderCol, AppShapes.medium)
                                        .clickable {
                                            onIconSelected(name)
                                            onDismiss()
                                        }
                                        .padding(vertical = AppSpacing.small)
                                ) {
                                    Icon(
                                        imageVector = getIconByName(name),
                                        contentDescription = displayName,
                                        modifier = Modifier.size(24.dp),
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = displayName.substringBefore(" /"),
                                        style = AppTypography.labelSmall.copy(fontSize = 10.sp),
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// UNIT PICKER DIALOG (Resolves "Automático" being confusing and improves selection UX)
@Composable
fun UnitPickerDialog(
    currentUnit: String,
    onUnitSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val units = listOf(
        "Automático" to "Detecta e agrupa unidades (Anos, Meses, Dias...)",
        "Anos" to "Exibe o tempo restante em anos",
        "Meses" to "Exibe o tempo restante em meses",
        "Semanas" to "Exibe o tempo restante em semanas",
        "Dias" to "Exibe o tempo de forma estrita em dias",
        "Horas" to "Exibe o tempo de forma estrita em horas",
        "Minutos" to "Exibe o tempo de forma estrita em minutos",
        "Segundos" to "Exibe o tempo de forma estrita em segundos"
    )
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = AppShapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(AppSpacing.medium),
                verticalArrangement = Arrangement.spacedBy(AppSpacing.medium)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Unidade de contagem",
                        style = AppTypography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Fechar")
                    }
                }
                
                Column(
                    verticalArrangement = Arrangement.spacedBy(AppSpacing.small)
                ) {
                    units.forEach { (unitKey, description) ->
                        val isSelected = currentUnit.lowercase() == unitKey.lowercase()
                        val bg by animateColorAsState(
                            targetValue = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent,
                            label = "unitCellBg"
                        )
                        val borderCol by animateColorAsState(
                            targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            label = "unitCellBorder"
                        )
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(AppShapes.medium)
                                .background(bg)
                                .border(1.dp, borderCol, AppShapes.medium)
                                .clickable {
                                    onUnitSelected(unitKey)
                                    onDismiss()
                                }
                                .padding(AppSpacing.medium),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = unitKey,
                                    style = AppTypography.bodyLarge,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = description,
                                    style = AppTypography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Selecionado",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
