package com.example.core.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object CreateEvent : Screen("create_event?eventId={eventId}&prefillTitle={prefillTitle}&prefillColor={prefillColor}&prefillIconName={prefillIconName}&prefillDaysLeft={prefillDaysLeft}") {
        fun createRoute(eventId: String? = null): String {
            return if (eventId != null) "create_event?eventId=$eventId" else "create_event"
        }
        fun createPrefillRoute(
            prefillTitle: String,
            prefillColorHex: String,
            prefillIconName: String,
            prefillDaysLeft: Int
        ): String {
            return "create_event?prefillTitle=${android.net.Uri.encode(prefillTitle)}&prefillColor=${android.net.Uri.encode(prefillColorHex)}&prefillIconName=${android.net.Uri.encode(prefillIconName)}&prefillDaysLeft=$prefillDaysLeft"
        }
    }
    object EventDetails : Screen("event_details/{eventId}") {
        fun createRoute(eventId: String) = "event_details/$eventId"
    }
    object Completed : Screen("completed")
    object Highlight : Screen("highlight/{eventId}") {
        fun createRoute(eventId: String) = "highlight/$eventId"
    }
    object More : Screen("more")
    object Intro : Screen("intro")
}
