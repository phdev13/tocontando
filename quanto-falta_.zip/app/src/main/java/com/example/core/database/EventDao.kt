package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM events")
    fun getAllEvents(): Flow<List<EventEntity>>
    
    @Query("SELECT * FROM events WHERE id = :id")
    fun getEventById(id: String): Flow<EventEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity)
    
    @Query("DELETE FROM events WHERE id = :id")
    suspend fun deleteEventById(id: String)
    
    @Query("UPDATE events SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun updateEventCompletedStatus(id: String, isCompleted: Boolean)
    
    @Query("DELETE FROM events")
    suspend fun deleteAllEvents()
    
    @Query("UPDATE events SET isArchived = :isArchived WHERE id = :id")
    suspend fun updateEventArchivedStatus(id: String, isArchived: Boolean)
}
