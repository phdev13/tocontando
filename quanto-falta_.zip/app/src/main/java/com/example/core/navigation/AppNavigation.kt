package com.example.core.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.QuantoFaltaApplication
import com.example.feature.home.HomeScreen
import com.example.feature.createevent.CreateEventScreen
import com.example.feature.eventdetails.EventDetailsScreen
import com.example.feature.completed.CompletedScreen
import com.example.feature.highlight.HighlightScreen
import com.example.feature.more.MoreScreen
import com.example.feature.intro.IntroScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current
    val appContainer = (context.applicationContext as QuantoFaltaApplication).container
    val isIntroCompleted by appContainer.introManager.isIntroCompleted.collectAsStateWithLifecycle(initialValue = null)

    if (isIntroCompleted == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    NavHost(
        navController = navController,
        startDestination = if (isIntroCompleted == true) Screen.Home.route else Screen.Intro.route
    ) {
        composable(Screen.Intro.route) {
            IntroScreen(
                onNavigate = { route ->
                    if (route == Screen.Home.route) {
                        navController.navigate(route) {
                            popUpTo(Screen.Intro.route) { inclusive = true }
                        }
                    } else if (route.startsWith("create_event")) {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Intro.route) { inclusive = true }
                        }
                        navController.navigate(route)
                    } else {
                        navController.navigate(route)
                    }
                }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(
            route = Screen.CreateEvent.route,
            arguments = listOf(
                androidx.navigation.navArgument("eventId") { 
                    nullable = true
                    type = androidx.navigation.NavType.StringType
                    defaultValue = null 
                },
                androidx.navigation.navArgument("prefillTitle") {
                    nullable = true
                    type = androidx.navigation.NavType.StringType
                    defaultValue = null
                },
                androidx.navigation.navArgument("prefillColor") {
                    nullable = true
                    type = androidx.navigation.NavType.StringType
                    defaultValue = null
                },
                androidx.navigation.navArgument("prefillIconName") {
                    nullable = true
                    type = androidx.navigation.NavType.StringType
                    defaultValue = null
                },
                androidx.navigation.navArgument("prefillDaysLeft") {
                    nullable = true
                    type = androidx.navigation.NavType.StringType
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId")
            val prefillTitle = backStackEntry.arguments?.getString("prefillTitle")
            val prefillColorHex = backStackEntry.arguments?.getString("prefillColor")
            val prefillIconName = backStackEntry.arguments?.getString("prefillIconName")
            val prefillDaysLeft = backStackEntry.arguments?.getString("prefillDaysLeft")?.toIntOrNull()
            CreateEventScreen(
                eventId = eventId,
                prefillTitle = prefillTitle,
                prefillColorHex = prefillColorHex,
                prefillIconName = prefillIconName,
                prefillDaysLeft = prefillDaysLeft,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.EventDetails.route) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            EventDetailsScreen(
                eventId = eventId,
                onBack = { navController.popBackStack() },
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Screen.Completed.route) {
            CompletedScreen(
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Screen.Highlight.route) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            HighlightScreen(
                eventId = eventId,
                onBack = { navController.popBackStack() },
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Screen.More.route) {
            MoreScreen(
                onNavigate = { route -> navController.navigate(route) }
            )
        }
    }
}
