package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey val id: String,
    val title: String,
    val dateMillis: Long,
    val createdAtMillis: Long,
    val unit: String,
    val colorArgb: Int,
    val iconName: String,
    val isCompleted: Boolean,
    val isArchived: Boolean
)
