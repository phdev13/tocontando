package com.example.core.designsystem.theme

import androidx.compose.ui.graphics.Color

val PurplePrimary = Color(0xFF7B61FF)
val BlueSecondary = Color(0xFF4A90FF)
val LightBlue = Color(0xFFA7C5FF)
val PurpleBackground = Color(0xFFEDE7FF)
val GrayBackground = Color(0xFFF4F6FA)

val DarkSurface = Color(0xFF1C1D2A)
val DarkSurfaceVariant = Color(0xFF2B2C3D)
val DarkBackground = Color(0xFF13141F)

val TextPrimaryLight = Color(0xFF14141F)
val TextSecondaryLight = Color(0xFF78788A)
val TextPrimaryDark = Color(0xFFF4F6FA)
val TextSecondaryDark = Color(0xFFAFAFB9)

val Colors = arrayOf(
    Color(0xFF7B61FF), // Purple
    Color(0xFF4A90FF), // Blue
    Color(0xFF34C759), // Green
    Color(0xFFFF9F0A), // Orange
    Color(0xFFFF453A), // Red
    Color(0xFFFF375F), // Pink
    Color(0xFF32ADE6)  // Cyan
)
