package com.example.core

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.QuantoFaltaApplication
import com.example.feature.home.HomeViewModel
import com.example.feature.createevent.CreateEventViewModel
import com.example.feature.eventdetails.EventDetailsViewModel
import com.example.feature.completed.CompletedViewModel

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            HomeViewModel(quantoFaltaApplication().container.eventRepository)
        }
        initializer {
            CreateEventViewModel(quantoFaltaApplication().container.eventRepository)
        }
        initializer {
            EventDetailsViewModel(quantoFaltaApplication().container.eventRepository)
        }
        initializer {
            CompletedViewModel(quantoFaltaApplication().container.eventRepository)
        }
        initializer {
            com.example.feature.highlight.HighlightViewModel(quantoFaltaApplication().container.eventRepository)
        }
        initializer {
            com.example.feature.intro.IntroViewModel(
                quantoFaltaApplication().container.introManager
            )
        }
        initializer {
            val app = quantoFaltaApplication()
            com.example.feature.more.MoreViewModel(
                app.container.eventRepository,
                app.container.themeManager,
                app.container.introManager
            )
        }
    }
}

fun CreationExtras.quantoFaltaApplication(): QuantoFaltaApplication =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as QuantoFaltaApplication)
