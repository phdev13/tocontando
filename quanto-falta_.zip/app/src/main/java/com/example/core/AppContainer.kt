package com.example.core

import android.content.Context
import com.example.core.database.AppDatabase
import com.example.data.repository.EventRepository
import com.example.core.designsystem.theme.ThemeManager
import com.example.core.preferences.IntroManager

class AppContainer(private val context: Context) {
    val database by lazy { AppDatabase.getDatabase(context) }
    val eventRepository by lazy { EventRepository(database.eventDao()) }
    val themeManager by lazy { ThemeManager(context) }
    val introManager by lazy { IntroManager(context) }
}
