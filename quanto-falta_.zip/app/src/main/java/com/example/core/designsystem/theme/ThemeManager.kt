package com.example.core.designsystem.theme

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ThemeManager(context: Context) {
    private val prefs = context.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)

    private val _themeState = MutableStateFlow(getThemePreference())
    val themeState: StateFlow<String> = _themeState.asStateFlow()

    fun setThemePreference(theme: String) {
        prefs.edit().putString("app_theme", theme).apply()
        _themeState.value = theme
    }

    private fun getThemePreference(): String {
        return prefs.getString("app_theme", "system") ?: "system"
    }
}
