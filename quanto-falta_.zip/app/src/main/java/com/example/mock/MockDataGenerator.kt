package com.example.mock

import androidx.compose.ui.graphics.toArgb
import com.example.core.database.EventEntity
import com.example.core.designsystem.theme.Colors
import java.util.UUID
import java.util.concurrent.TimeUnit

object MockDataGenerator {
    fun generateMockEvents(): List<EventEntity> {
        val now = System.currentTimeMillis()
        
        return listOf(
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = "Viagem para Salvador 🏖️",
                dateMillis = now + TimeUnit.DAYS.toMillis(45),
                createdAtMillis = now - TimeUnit.DAYS.toMillis(5),
                unit = "Automático",
                colorArgb = Colors[1].toArgb(), // Blue
                iconName = "BeachAccess",
                isCompleted = false,
                isArchived = false
            ),
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = "Aniversário da Mãe 🎂",
                dateMillis = now + TimeUnit.DAYS.toMillis(12),
                createdAtMillis = now - TimeUnit.DAYS.toMillis(10),
                unit = "Dias",
                colorArgb = Colors[5].toArgb(), // Pink
                iconName = "Cake",
                isCompleted = false,
                isArchived = false
            ),
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = "Estreia do Novo Filme 🍿",
                dateMillis = now + TimeUnit.HOURS.toMillis(6),
                createdAtMillis = now - TimeUnit.DAYS.toMillis(2),
                unit = "Horas",
                colorArgb = Colors[3].toArgb(), // Orange
                iconName = "Movie",
                isCompleted = false,
                isArchived = false
            ),
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = "Show de Rock Especial 🎸",
                dateMillis = now + TimeUnit.DAYS.toMillis(90),
                createdAtMillis = now - TimeUnit.DAYS.toMillis(1),
                unit = "Semanas",
                colorArgb = Colors[0].toArgb(), // Purple
                iconName = "MusicNote",
                isCompleted = false,
                isArchived = false
            ),
            EventEntity(
                id = UUID.randomUUID().toString(),
                title = "Maratona de São Silvestre 🏃",
                dateMillis = now + TimeUnit.DAYS.toMillis(200),
                createdAtMillis = now - TimeUnit.DAYS.toMillis(15),
                unit = "Automático",
                colorArgb = Colors[2].toArgb(), // Green
                iconName = "Star",
                isCompleted = false,
                isArchived = false
            )
        )
    }
}
