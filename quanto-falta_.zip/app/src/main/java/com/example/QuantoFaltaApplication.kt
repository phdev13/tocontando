package com.example

import android.app.Application
import com.example.core.AppContainer

class QuantoFaltaApplication : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
