import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Sidebar } from '@/components/layout/Sidebar';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'Quanto Falta? - Admin',
  description: 'Painel Administrativo do App Quanto Falta?',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable}`}>
      <body className="bg-[var(--color-background)] text-[var(--color-primary)] antialiased" suppressHydrationWarning>
        <div className="min-h-screen">
          <Sidebar />
          <div className="lg:pl-64 flex flex-col min-h-screen">
            <main className="flex-1 py-10 px-4 sm:px-8 lg:px-10 max-w-7xl mx-auto w-full">
              {children}
            </main>
          </div>
        </div>
      </body>
    </html>
  );
}
