'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Calendar, Filter, Download } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';

const data30Days = [
  { name: '01 Jun', aquisicao: 4000, retencao: 2400 },
  { name: '05 Jun', aquisicao: 3000, retencao: 1398 },
  { name: '10 Jun', aquisicao: 2000, retencao: 9800 },
  { name: '15 Jun', aquisicao: 2780, retencao: 3908 },
  { name: '20 Jun', aquisicao: 1890, retencao: 4800 },
  { name: '25 Jun', aquisicao: 2390, retencao: 3800 },
  { name: '30 Jun', aquisicao: 3490, retencao: 4300 },
];

const data7Days = [
  { name: 'Seg', aquisicao: 400, retencao: 240 },
  { name: 'Ter', aquisicao: 300, retencao: 139 },
  { name: 'Qua', aquisicao: 200, retencao: 980 },
  { name: 'Qui', aquisicao: 278, retencao: 390 },
  { name: 'Sex', aquisicao: 189, retencao: 480 },
  { name: 'Sáb', aquisicao: 239, retencao: 380 },
  { name: 'Dom', aquisicao: 349, retencao: 430 },
];

const originData = [
  { name: 'Play Store', value: 75, color: '#10b981' }, // Emerald
  { name: 'Site / Side-load', value: 15, color: '#8b5cf6' }, // Purple
  { name: 'Indicação', value: 10, color: '#f59e0b' }, // Amber
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-3 rounded-lg shadow-xl">
        <p className="text-[12px] font-bold text-white mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
            <p className="text-[12px] text-[var(--color-primary-muted)] font-medium">
              {entry.name}: <span className="text-white font-bold">{entry.value}</span>
            </p>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function MetricsPage() {
  const [period, setPeriod] = useState('30d');

  const lineData = period === '30d' ? data30Days : data7Days;

  return (
    <div className="space-y-6 pb-12 relative flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Métricas Analíticas</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Análise aprofundada de uso, retenção e aquisição.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] rounded-xl flex overflow-hidden">
            <button 
              onClick={() => setPeriod('7d')}
              className={`px-3 py-2 text-[12px] font-medium transition-colors ${period === '7d' ? 'bg-[var(--color-border)] text-white' : 'text-[var(--color-primary-muted)] hover:text-white'}`}
            >
              7 Dias
            </button>
            <button 
              onClick={() => setPeriod('30d')}
              className={`px-3 py-2 text-[12px] font-medium transition-colors ${period === '30d' ? 'bg-[var(--color-border)] text-white' : 'text-[var(--color-primary-muted)] hover:text-white'}`}
            >
              30 Dias
            </button>
          </div>
          <button className="flex items-center gap-2 rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-hover)] px-4 py-2 text-[13px] font-medium text-[var(--color-primary-muted)] hover:text-white hover:bg-[var(--color-border)] transition-colors">
            <Download className="h-4 w-4" />
            Exportar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        {[
          { title: 'Usuários Ativos (DAU)', value: period === '30d' ? '8.4k' : '2.1k', up: true, trend: '+4%' },
          { title: 'Tempo Médio', value: '4m 12s', up: false, trend: '-1%' },
          { title: 'Sessões Mídia', value: period === '30d' ? '24.5k' : '6.2k', up: true, trend: '+12%' },
          { title: 'Crash Free Users', value: '99.8%', up: true, trend: '+0.1%' },
        ].map((m) => (
          <Card key={m.title} className="shadow-sm">
            <CardContent className="p-5 flex flex-col justify-center">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">{m.title}</p>
              <div className="mt-1 flex items-baseline gap-2">
                <p className="text-4xl font-bold text-white drop-shadow-sm">{m.value}</p>
                <span className={`text-[12px] font-bold ${m.up ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {m.trend}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 border-t border-[var(--color-border)] pt-6">
        <div className="lg:col-span-2">
          <Card className="shadow-sm h-full">
            <CardHeader className="p-5 pb-0">
               <h3 className="text-lg font-bold text-white">Aquisição vs Retenção</h3>
               <p className="text-[13px] text-[var(--color-primary-muted)]">Fluxo de novos usuários interagindo com o app.</p>
            </CardHeader>
            <CardContent className="p-5 h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={lineData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f1e24" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8b8a91' }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8b8a91' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="aquisicao" name="Aquisição" stroke="#8b5cf6" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                  <Line type="monotone" dataKey="retencao" name="Retenção" stroke="#10b981" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="shadow-sm h-full">
            <CardHeader className="p-5 pb-0">
               <h3 className="text-lg font-bold text-white">Origem de Instalação</h3>
               <p className="text-[13px] text-[var(--color-primary-muted)]">Divisão de plataformas de entrada.</p>
            </CardHeader>
            <CardContent className="p-5 flex flex-col items-center justify-center h-[350px]">
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={originData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value" stroke="none">
                      {originData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="w-full space-y-3 mt-4">
                 {originData.map((item) => (
                   <div key={item.name} className="flex items-center justify-between">
                     <div className="flex items-center gap-2">
                       <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                       <span className="text-[13px] font-medium text-white">{item.name}</span>
                     </div>
                     <span className="text-[13px] font-bold text-[var(--color-primary-muted)]">{item.value}%</span>
                   </div>
                 ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
