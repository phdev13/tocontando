'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Database, ShieldAlert } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Configurações Base</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Preferências globais do painel administrativo.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <Card className="shadow-sm">
          <CardHeader className="p-5 pb-0">
            <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
              <Database className="w-5 h-5 text-purple-400" /> Integração de API
            </CardTitle>
            <CardDescription className="text-[13px] text-[var(--color-primary-muted)] mt-1">Endpoints base do Cloudflare Workers</CardDescription>
          </CardHeader>
          <CardContent className="p-5 space-y-4">
            <div>
              <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Base URL (Produção)</label>
              <input 
                type="text" 
                disabled 
                value="https://api.quantofalta.shop/v1" 
                className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2.5 text-white text-[13px] opacity-60 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Status da Camada D1</label>
              <div className="flex items-center gap-2 mt-2 text-[13px] text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-3 py-2 rounded-xl w-fit">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                Conectado e Saudável
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="p-5 pb-0">
            <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" /> Autenticação Root
            </CardTitle>
            <CardDescription className="text-[13px] text-[var(--color-primary-muted)] mt-1">Gerido estritamente no nível Edge (Access)</CardDescription>
          </CardHeader>
          <CardContent className="p-5 space-y-4">
            <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4">
              <p className="text-[13px] text-amber-500 font-bold">Aviso de Segurança Zero-Trust</p>
              <p className="text-[13px] text-[var(--color-primary-muted)] mt-2 leading-relaxed">
                Este frontend <span className="text-white font-medium">não lida com tokens locais senhas de administrador</span>. Toda a proteção de rotas é imposta pelas regras do Cloudflare Access sobre a restrição de email "philippeboechat1@gmail.com".
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
