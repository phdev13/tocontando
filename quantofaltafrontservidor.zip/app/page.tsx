'use client';

import Link from 'next/link';
import { Activity, Download, Users, Heart, Star, ArrowUpRight, RefreshCw, Calendar, AlertTriangle, Play, CheckCircle2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const mockInstalacoes = Array.from({ length: 30 }, (_, i) => ({
  date: `${i + 1} Mai`,
  value: Math.floor(Math.random() * 200) + 100 + (i * 10),
}));

const mockRetencao = Array.from({ length: 30 }, (_, i) => ({
  date: `${i + 1} Mai`,
  d7: 50 - (i * 0.5) + (Math.random() * 5),
  d30: 25 - (i * 0.2) + (Math.random() * 3),
}));

export default function Dashboard() {
  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Dashboard</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Visão geral do Quanto Falta?</p>
        </div>
        <div className="flex items-center gap-4 text-sm text-[var(--color-primary-muted)]">
          <div className="flex items-center gap-2 bg-[var(--color-surface-hover)] border border-[var(--color-border)] px-3 py-2 rounded-xl text-white">
            <Calendar className="w-4 h-4 text-[var(--color-primary-muted)]"/>
            <span className="font-medium">Últimos 30 dias</span>
          </div>
          <span className="hidden sm:inline">Atualizado em 20 de mai. de 2024, 18:30</span>
          <button className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard 
          icon={Download} 
          label="Instalações" 
          value="1.248" 
          change="+18,6%" 
          changeType="positive"
          sparkData={mockInstalacoes.map(d => d.value)}
        />
        <StatCard 
          icon={Users} 
          label="Usuários ativos" 
          value="842" 
          change="+12,3%" 
          changeType="positive"
          sparkData={mockInstalacoes.map(d => d.value - 20)}
        />
        <StatCard 
          icon={Heart} 
          label="Retenção D7" 
          value="32,4%" 
          change="+4,7 p.p." 
          changeType="positive"
          sparkData={mockRetencao.map(d => d.d7)}
        />
        <StatCard 
          icon={Star} 
          label="Avaliação média" 
          value="4,8" 
          change="+0,3" 
          changeType="positive"
          sparkData={[4.1, 4.2, 4.5, 4.4, 4.7, 4.8]}
        />
      </div>

      {/* Main Grid 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2 p-6 flex flex-col min-h-[400px]">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="font-semibold text-white">Crescimento de instalações</h3>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                <span className="text-[13px] text-[var(--color-primary-muted)]">Instalações diárias</span>
              </div>
            </div>
            <div className="bg-[var(--color-surface-hover)] border border-[var(--color-border)] px-3 py-1.5 rounded-lg text-sm text-white">
              Diário
            </div>
          </div>
          <div className="flex-1 w-full min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockInstalacoes} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorInstalacoes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8b8a91' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#8b8a91' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151419', borderColor: '#1f1e24', borderRadius: '8px', color: '#fff' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} fillOpacity={1} fill="url(#colorInstalacoes)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="flex flex-col gap-5">
          <Card className="p-6">
            <h3 className="font-semibold text-white mb-6">Saúde do app</h3>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-emerald-400">Tudo certo! 🎉</p>
                <p className="text-[13px] text-[var(--color-primary-muted)] mt-1">Nenhum problema crítico detectado.</p>
              </div>
              <div className="relative w-16 h-16 flex items-center justify-center rounded-full border-4 border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-500 border-l-transparent border-b-transparent transform rotate-45"></div>
                <span className="font-bold text-white text-sm">100%</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 flex-1">
            <h3 className="font-semibold text-white">Distribuição de versões</h3>
            <p className="text-[13px] text-[var(--color-primary-muted)] mt-1 mb-6">Baseado em instalações ativas</p>
            
            <div className="space-y-4">
              <VersionBar version="1.0.0" percent="68%" width="68%" />
              <VersionBar version="0.9.5" percent="24%" width="24%" />
              <VersionBar version="0.9.0 e anteriores" percent="8%" width="8%" />
            </div>

            <Link href="/ota" className="text-purple-400 text-[13px] font-medium mt-6 flex items-center gap-1 hover:text-purple-300 w-fit">
              Ver todas as versões <ArrowUpRight className="w-3 h-3"/>
            </Link>
          </Card>
        </div>
      </div>

      {/* Main Grid 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="font-semibold text-white">Retenção de usuários</h3>
              <div className="flex items-center gap-3 mt-1">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-purple-500"></div><span className="text-[12px] text-[var(--color-primary-muted)]">D7</span></div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-purple-300"></div><span className="text-[12px] text-[var(--color-primary-muted)]">D30</span></div>
              </div>
            </div>
            <div className="bg-[var(--color-surface-hover)] border border-[var(--color-border)] px-2 py-1 rounded text-xs text-white">
              Diário
            </div>
          </div>
          <div className="h-[180px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockRetencao} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#8b8a91' }} dy={5} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#8b8a91' }} />
                <Tooltip contentStyle={{ backgroundColor: '#151419', borderColor: '#1f1e24', borderRadius: '8px' }}/>
                <Line type="monotone" dataKey="d7" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="d30" stroke="#d8b4fe" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-semibold text-white">Atividade recente</h3>
          </div>
          <div className="space-y-4">
            <ActivityItem 
              icon={AlertTriangle} 
              iconColor="text-red-400" 
              iconBg="bg-red-400/10"
              title="Nova versão publicada"
              desc="Versão 1.0.0 publicada com sucesso"
              time="Hoje, 16:42"
            />
            <ActivityItem 
              icon={Users} 
              iconColor="text-purple-400" 
              iconBg="bg-purple-400/10"
              title="Novo feedback recebido"
              desc="Usuário relatou um problema no login"
              time="Hoje, 15:18"
            />
            <ActivityItem 
              icon={CheckCircle2} 
              iconColor="text-emerald-400" 
              iconBg="bg-emerald-400/10"
              title="Novo tester aprovado"
              desc="joao.silva@email.com foi adicionado"
              time="Hoje, 14:03"
            />
          </div>
          <Link href="/logs" className="text-purple-400 text-[13px] font-medium mt-6 flex items-center gap-1 hover:text-purple-300 w-fit">
            Ver todas as atividades <ArrowUpRight className="w-3 h-3"/>
          </Link>
        </Card>

        <Card className="p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-semibold text-white">Alertas importantes</h3>
          </div>
          
          <div className="bg-[var(--color-surface-hover)] border border-[var(--color-border)] p-4 rounded-xl mt-auto">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-[14px] font-medium text-white">Taxa de retenção D7 abaixo da média</p>
                <p className="text-[13px] text-[var(--color-primary-muted)] mt-1 mb-3">A retenção D7 caiu 8% nos últimos 3 dias.</p>
                <Link href="/metrics" className="text-purple-400 text-[13px] font-medium flex items-center gap-1 hover:text-purple-300 w-fit">
                  Ver detalhes <ArrowUpRight className="w-3 h-3"/>
                </Link>
              </div>
            </div>
          </div>
        </Card>
      </div>

    </div>
  );
}

function StatCard({ icon: Icon, label, value, change, changeType, sparkData }: any) {
  return (
    <Card className="p-5 flex flex-col gap-4">
      <div className="flex items-center gap-3">
        <div className="bg-purple-600/20 text-purple-400 p-2.5 rounded-xl shrink-0 border border-purple-500/20">
          <Icon className="w-6 h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[13px] text-[var(--color-primary-muted)] font-medium truncate">{label}</p>
          <p className="text-2xl font-bold text-white mt-0.5">{value}</p>
        </div>
        <div className="w-16 h-8 shrink-0">
          {sparkData && sparkData.length > 0 && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sparkData.map((v: any, i: any) => ({ val: v, ix: i }))}>
                <Line type="monotone" dataKey="val" stroke={changeType === 'positive' ? '#10b981' : '#ef4444'} strokeWidth={1.5} dot={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5 text-[12px]">
        {changeType === 'positive' ? (
          <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
        ) : (
          <ArrowUpRight className="w-3.5 h-3.5 text-red-400 transform rotate-90" />
        )}
        <span className={changeType === 'positive' ? 'text-emerald-400 font-medium' : 'text-red-400 font-medium'}>
          {change}
        </span>
        <span className="text-[var(--color-primary-muted)]">vs. período anterior</span>
      </div>
    </Card>
  );
}

function VersionBar({ version, percent, width }: any) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-24 shrink-0">
        <p className="text-[13px] text-[var(--color-primary-muted)]">{version}</p>
      </div>
      <div className="flex-1 h-1.5 bg-[var(--color-border)] rounded-full overflow-hidden">
        <div className="h-full bg-purple-500 rounded-full" style={{ width }} />
      </div>
      <div className="w-10 text-right shrink-0">
        <p className="text-[13px] text-white font-medium">{percent}</p>
      </div>
    </div>
  );
}

function ActivityItem({ icon: Icon, iconColor, iconBg, title, desc, time }: any) {
  return (
    <div className="flex items-start gap-3">
      <div className={`p-2 rounded-xl shrink-0 ${iconBg} ${iconColor}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-medium text-white truncate">{title}</p>
        <p className="text-[12px] text-[var(--color-primary-muted)] truncate mt-0.5">{desc}</p>
      </div>
      <div className="shrink-0 text-right">
        <span className="text-[11px] text-[var(--color-primary-muted)]">{time}</span>
      </div>
    </div>
  );
}
