'use client';

import { useState } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/Table';
import { Badge } from '@/components/ui/Badge';
import { UploadCloud, CheckCircle2, AlertCircle, Play, Pause, X, Trash2, FileText, Info } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';

const initialOTAs = [
  { version: '1.2.0', code: 24, channel: 'produção', status: 'active', date: '01 Jun 2026', mandatory: false, adoption: '88%', successRate: '99.8%', details: 'Melhorias de performance e correções gerais.' },
  { version: '1.2.1-beta', code: 25, channel: 'beta', status: 'paused', date: '10 Jun 2026', mandatory: false, adoption: '12%', successRate: '94.2%', details: 'Introdução do novo tema amoled.' },
  { version: '1.1.9', code: 23, channel: 'produção', status: 'archived', date: '15 Mai 2026', mandatory: true, adoption: '100%', successRate: '99.9%', details: 'Atualização crítica de segurança.' },
];

export default function OTAPage() {
  const [otas, setOtas] = useState(initialOTAs);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedOTA, setSelectedOTA] = useState<typeof initialOTAs[0] | null>(null);

  const [newVersion, setNewVersion] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newChannel, setNewChannel] = useState('produção');
  const [isMandatory, setIsMandatory] = useState(false);

  const toggleStatus = (version: string) => {
    setOtas(v => v.map(o => {
      if (o.version === version) {
        if (o.status === 'active') return { ...o, status: 'paused' };
        if (o.status === 'paused') return { ...o, status: 'active' };
      }
      return o;
    }));
  };

  const handleDeleteOTA = (version: string) => {
    setOtas(v => v.filter(o => o.version !== version));
  };

  const openDetails = (ota: typeof initialOTAs[0]) => {
    setSelectedOTA(ota);
    setIsDetailsModalOpen(true);
  };

  const handleAddOTA = () => {
    const defaultDate = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).replace('.', '');
    const newOta = {
      version: newVersion,
      code: parseInt(newCode) || Math.floor(Math.random() * 100),
      channel: newChannel,
      status: 'active',
      date: defaultDate,
      mandatory: isMandatory,
      adoption: '0%',
      successRate: '100%',
      details: 'Sem descrição fornecida.'
    };
    setOtas(v => [newOta, ...v]);
    setIsModalOpen(false);
    setNewVersion('');
    setNewCode('');
    setNewChannel('produção');
    setIsMandatory(false);
  };

  return (
    <div className="space-y-6 pb-12 relative">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">OTA & Versões</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Gerencie atualizações remotas distribuídas via Cloudflare Workers.</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white border border-purple-500/50 px-4 py-2 rounded-xl transition-colors text-sm font-medium">
            <UploadCloud className="h-4 w-4" />
            Nova Atualização
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="shadow-sm">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="rounded-xl bg-emerald-500/10 p-3 text-emerald-400">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Taxa de Sucesso</p>
              <p className="text-2xl font-bold text-white mt-0.5">99.8%</p>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="rounded-xl bg-amber-500/10 p-3 text-amber-400">
              <AlertCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Falhas Críticas</p>
              <p className="text-2xl font-bold text-white mt-0.5">0.2%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="bg-[var(--color-surface-hover)] rounded-2xl overflow-hidden border border-[var(--color-border)]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Versão</TableHead>
              <TableHead>Canal</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Publicação</TableHead>
              <TableHead>Adoção</TableHead>
              <TableHead>Sucesso</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {otas.map((ota) => (
              <TableRow key={ota.version}>
                <TableCell>
                  <div className="font-mono font-bold text-[14px] text-white">v{ota.version}</div>
                  <div className="text-[12px] text-[var(--color-primary-muted)] mt-0.5 font-medium">Build {ota.code} {ota.mandatory && <span className="text-amber-400 font-bold ml-1 border-l border-[var(--color-border-hover)] pl-1.5">• Obrigatória</span>}</div>
                </TableCell>
                <TableCell>
                  <Badge variant={ota.channel === 'produção' ? 'default' : 'secondary'} className="uppercase text-[10px] font-bold px-2 py-0.5">
                    {ota.channel}
                  </Badge>
                </TableCell>
                <TableCell>
                  {ota.status === 'active' && <Badge variant="success" className="px-2 py-0.5">Em Distribuição</Badge>}
                  {ota.status === 'paused' && <Badge variant="warning" className="px-2 py-0.5">Pausada</Badge>}
                  {ota.status === 'archived' && <Badge variant="secondary" className="px-2 py-0.5">Arquivada</Badge>}
                </TableCell>
                <TableCell className="text-[13px] text-[var(--color-primary-muted)] font-medium">{ota.date}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 w-16 bg-[var(--color-border)] rounded-full overflow-hidden shrink-0">
                      <div className="h-full bg-purple-500 rounded-full" style={{ width: ota.adoption }} />
                    </div>
                    <span className="text-[12px] font-bold text-white w-8 shrink-0">{ota.adoption}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className={`text-[13px] font-bold ${parseFloat(ota.successRate) > 95 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {ota.successRate}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-5 items-center">
                    {ota.status === 'active' ? (
                      <button onClick={() => toggleStatus(ota.version)} className="text-amber-500 hover:text-amber-400 transition-colors" title="Pausar">
                        <Pause className="h-[18px] w-[18px] stroke-[1.5]" />
                      </button>
                    ) : ota.status === 'paused' ? (
                      <button onClick={() => toggleStatus(ota.version)} className="text-emerald-500 hover:text-emerald-400 transition-colors" title="Retomar">
                        <Play className="h-[18px] w-[18px] stroke-[1.5]" />
                      </button>
                    ) : (
                      <div className="w-[18px] h-[18px]" />
                    )}
                    <button onClick={() => openDetails(ota)} className="text-blue-500 hover:text-blue-400 transition-colors" title="Detalhes">
                      <FileText className="h-[18px] w-[18px] stroke-[1.5]" />
                    </button>
                    <button onClick={() => handleDeleteOTA(ota.version)} className="text-red-500 hover:text-red-400 transition-colors" title="Excluir">
                      <Trash2 className="h-[18px] w-[18px] stroke-[1.5]" />
                    </button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Details Modal */}
      {isDetailsModalOpen && selectedOTA && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] shadow-2xl rounded-2xl w-full max-w-sm overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-[var(--color-border)]">
               <h3 className="text-lg font-bold text-white flex items-center gap-2">
                 <Info className="w-5 h-5 text-purple-400" /> Detalhes da Versão
               </h3>
               <button onClick={() => setIsDetailsModalOpen(false)} className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <div className="p-5 flex-1 relative custom-scrollbar space-y-4">
              <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-3">
                 <span className="text-[13px] font-medium text-[var(--color-primary-muted)]">Versão</span>
                 <span className="text-[14px] font-bold text-white">v{selectedOTA.version} (Build {selectedOTA.code})</span>
              </div>
              <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-3">
                 <span className="text-[13px] font-medium text-[var(--color-primary-muted)]">Data de Publicação</span>
                 <span className="text-[14px] font-bold text-white">{selectedOTA.date}</span>
              </div>
              <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-3">
                 <span className="text-[13px] font-medium text-[var(--color-primary-muted)]">Adoção</span>
                 <span className="text-[14px] font-bold text-white">{selectedOTA.adoption}</span>
              </div>
              <div className="flex items-center justify-between border-b border-[var(--color-border)] pb-3">
                 <span className="text-[13px] font-medium text-[var(--color-primary-muted)]">Taxa de Sucesso</span>
                 <span className={`text-[14px] font-bold ${parseFloat(selectedOTA.successRate) > 95 ? 'text-emerald-400' : 'text-amber-400'}`}>{selectedOTA.successRate}</span>
              </div>
              <div>
                 <span className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Descrição / Changelog</span>
                 <div className="p-3 bg-[var(--color-surface-hover)] rounded-xl border border-[var(--color-border)] text-[13px] text-[var(--color-primary-muted)] leading-relaxed">
                   {selectedOTA.details}
                 </div>
              </div>
            </div>

            <div className="p-5 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-[var(--color-surface-hover)]">
               <button onClick={() => setIsDetailsModalOpen(false)} className="px-4 py-2 text-[14px] font-medium text-white bg-purple-600 hover:bg-purple-700 rounded-xl transition-colors">
                 Fechar
               </button>
            </div>
          </div>
        </div>
      )}

      {/* New OTA Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] shadow-2xl rounded-2xl w-full max-w-sm overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-[var(--color-border)]">
               <h3 className="text-lg font-bold text-white">Nova Atualização</h3>
               <button onClick={() => setIsModalOpen(false)} className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <div className="p-5 flex-1 relative custom-scrollbar space-y-4">
               <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Versão (Ex: 1.2.2)</label>
                    <input type="text" value={newVersion} onChange={e => setNewVersion(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" />
                 </div>
                 <div>
                    <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Build Code</label>
                    <input type="number" value={newCode} onChange={e => setNewCode(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" />
                 </div>
               </div>
               <div>
                  <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Canal de Distribuição</label>
                  <select value={newChannel} onChange={e => setNewChannel(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2.5 text-white text-[14px] focus:outline-none focus:border-purple-500/50 appearance-none">
                    <option value="produção">Produção</option>
                    <option value="beta">Beta</option>
                    <option value="alpha">Alpha</option>
                  </select>
               </div>
               <div className="pt-2">
                 <label className="flex items-center gap-3 cursor-pointer">
                   <input type="checkbox" checked={isMandatory} onChange={e => setIsMandatory(e.target.checked)} className="w-4 h-4 rounded border-[var(--color-border)] bg-[var(--color-surface-hover)] text-purple-600 focus:ring-purple-500/50" />
                   <span className="text-[13px] font-medium text-white">Atualização Obrigatória</span>
                 </label>
                 <p className="text-[12px] text-[var(--color-primary-muted)] ml-7 mt-1">O app exigirá atualização para continuar funcionando.</p>
               </div>
            </div>

            <div className="p-5 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-[var(--color-surface-hover)]">
               <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-[14px] font-medium text-white bg-transparent hover:bg-[var(--color-border)] rounded-xl transition-colors">Cancelar</button>
               <button onClick={handleAddOTA} disabled={!newVersion} className="px-4 py-2 text-[14px] font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-colors">
                 Distribuir
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
