'use client';

import { useState } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/Table';
import { Badge } from '@/components/ui/Badge';
import { Card, CardContent } from '@/components/ui/Card';
import { Plus, EyeOff, Eye, Globe, Edit2, Trash2, CheckCircle2, X } from 'lucide-react';

const initialTesters = [
  { 
    id: '1', 
    name: 'Rafaela Tasso', 
    role: '—',
    initials: 'RA',
    version: 'v1.0', 
    badgeTitle: 'Tester Inicial', 
    message: 'Primeira a dar feedback e ut...', 
    consent: true, 
    status: 'Ativo',
    published: true,
    hidden: false
  },
];

export default function TestersPage() {
  const [testers, setTesters] = useState(initialTesters);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTesterId, setEditingTesterId] = useState<string | null>(null);
  
  // Form state
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [version, setVersion] = useState('');
  const [badgeTitle, setBadgeTitle] = useState('');
  const [message, setMessage] = useState('');

  const handleOpenModal = (tester?: typeof initialTesters[0]) => {
    if (tester) {
      setEditingTesterId(tester.id);
      setName(tester.name);
      setRole(tester.role);
      setVersion(tester.version);
      setBadgeTitle(tester.badgeTitle);
      setMessage(tester.message);
    } else {
      setEditingTesterId(null);
      setName('');
      setRole('');
      setVersion('');
      setBadgeTitle('');
      setMessage('');
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleSave = () => {
    if (editingTesterId) {
      setTesters(v => v.map(t => t.id === editingTesterId ? { ...t, name, role, version, badgeTitle, message } : t));
    } else {
      const newTester = {
        id: Math.random().toString(36).substring(7),
        name,
        role: role || '—',
        initials: name.substring(0, 2).toUpperCase(),
        version,
        badgeTitle,
        message,
        consent: false,
        status: 'Pendente',
        published: false,
        hidden: false
      };
      setTesters(v => [...v, newTester]);
    }
    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    setTesters(v => v.filter(t => t.id !== id));
  };

  const togglePublish = (id: string) => {
    setTesters(v => v.map(t => t.id === id ? { ...t, published: !t.published, status: !t.published ? 'Ativo' : t.status } : t));
  };

  const toggleHidden = (id: string) => {
    setTesters(v => v.map(t => t.id === id ? { ...t, hidden: !t.hidden } : t));
  };

  const totalTesters = testers.length;
  const actives = testers.filter(t => t.status === 'Ativo').length;
  const published = testers.filter(t => t.published).length;
  const pendents = testers.filter(t => t.status === 'Pendente').length;

  return (
    <div className="space-y-6 pb-12 relative">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Gestão de Testers</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Agradecimentos, consentimentos e controle de publicação</p>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <button onClick={() => handleOpenModal()} className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white border border-purple-500/50 px-4 py-2 rounded-xl transition-colors font-medium">
            <Plus className="h-4 w-4" />
            Novo Tester
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Total de Testers</p>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">{totalTesters}</p>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm shadow-emerald-900/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-xl -mr-10 -mt-10"></div>
          <CardContent className="p-5 flex flex-col justify-center relative z-10">
            <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Ativos no App</p>
            <p className="text-4xl font-bold text-emerald-400 mt-1 drop-shadow-sm">{actives}</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm shadow-blue-900/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-xl -mr-10 -mt-10"></div>
          <CardContent className="p-5 flex flex-col justify-center relative z-10">
            <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Publicados</p>
            <p className="text-4xl font-bold text-blue-400 mt-1 drop-shadow-sm">{published}</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm shadow-amber-900/10 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-xl -mr-10 -mt-10"></div>
          <CardContent className="p-5 flex flex-col justify-center relative z-10">
            <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Pendentes (Consentimento)</p>
            <p className="text-4xl font-bold text-amber-500 mt-1 drop-shadow-sm">{pendents}</p>
          </CardContent>
        </Card>
      </div>

      <div className="bg-[var(--color-surface-hover)] rounded-2xl overflow-hidden border border-[var(--color-border)]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[200px]">Perfil</TableHead>
              <TableHead>Versão/Selo</TableHead>
              <TableHead className="w-1/3">Mensagem</TableHead>
              <TableHead>Consentimento</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {testers.map((tester) => (
              <TableRow key={tester.id} className={tester.hidden ? 'opacity-40 grayscale' : ''}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 shrink-0 rounded-full border border-[var(--color-border-hover)] bg-[var(--color-surface)] flex items-center justify-center font-bold text-white text-[13px]">
                      {tester.initials}
                    </div>
                    <div>
                      <div className="font-bold text-[14px] text-white flex items-center gap-1.5">
                        {tester.name} 
                        {tester.published && <span className="text-purple-400 text-[10px]">★</span>}
                      </div>
                      <div className="text-[12px] text-[var(--color-primary-muted)] mt-0.5">{tester.role}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1.5 items-start">
                    <span className="rounded-full bg-blue-500/20 text-blue-400 px-2 py-0.5 text-[11px] font-bold border border-blue-500/20">{tester.version}</span>
                    <span className="text-[12px] font-medium text-white">{tester.badgeTitle}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-[14px] font-medium text-white">{tester.message}</span>
                </TableCell>
                <TableCell>
                  {tester.consent && (
                    <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 text-[12px] font-bold">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      OK
                    </div>
                  )}
                  {!tester.consent && (
                    <span className="text-[12px] font-medium text-amber-500">Pendente</span>
                  )}
                </TableCell>
                <TableCell>
                   <div className="flex flex-col gap-1.5 items-start">
                     {tester.status === 'Ativo' && (
                       <span className="rounded-full bg-emerald-500/20 text-emerald-400 px-2.5 py-0.5 text-[11px] font-bold border border-emerald-500/20">Ativo</span>
                     )}
                     {tester.status === 'Pendente' && (
                       <span className="rounded-full bg-amber-500/20 text-amber-400 px-2.5 py-0.5 text-[11px] font-bold border border-amber-500/20">Pendente</span>
                     )}
                     {tester.published && (
                       <span className="text-[12px] font-medium text-white">Publicado</span>
                     )}
                     {!tester.published && tester.status === 'Ativo' && (
                       <span className="text-[12px] font-medium text-[var(--color-primary-muted)]">Não Publicado</span>
                     )}
                   </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-5">
                    <button onClick={() => toggleHidden(tester.id)} className={`${tester.hidden ? 'text-white' : 'text-[var(--color-primary-muted)]'} hover:text-white transition-colors`} title={tester.hidden ? "Mostrar" : "Ocultar"}>
                      {tester.hidden ? <Eye className="h-[18px] w-[18px] stroke-[1.5]" /> : <EyeOff className="h-[18px] w-[18px] stroke-[1.5]" />}
                    </button>
                    <button onClick={() => togglePublish(tester.id)} className={`${tester.published ? 'text-blue-500' : 'text-[var(--color-primary-muted)]'} hover:text-blue-400 transition-colors`} title="Publicar/Despublicar">
                      <Globe className="h-[18px] w-[18px] stroke-[1.5]" />
                    </button>
                    <button onClick={() => handleOpenModal(tester)} className="text-purple-500 hover:text-purple-400 transition-colors" title="Editar">
                      <Edit2 className="h-[18px] w-[18px] stroke-[1.5]" />
                    </button>
                    <button onClick={() => handleDelete(tester.id)} className="text-red-500 hover:text-red-400 transition-colors" title="Excluir">
                      <Trash2 className="h-[18px] w-[18px] stroke-[1.5]" />
                    </button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {testers.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-12 text-[var(--color-primary-muted)]">
                  Nenhum tester encontrado. Clique em "Novo Tester" para adicionar.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] shadow-2xl rounded-2xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-[var(--color-border)]">
               <h3 className="text-lg font-bold text-white">{editingTesterId ? 'Editar Tester' : 'Novo Tester'}</h3>
               <button onClick={handleCloseModal} className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            <div className="p-5 space-y-4">
               <div>
                  <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Nome</label>
                  <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" placeholder="Ex: Rafaela Tasso" />
               </div>
               <div>
                  <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Cargo / Papel</label>
                  <input type="text" value={role} onChange={e => setRole(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" placeholder="Ex: QA Analyst" />
               </div>
               <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Versão</label>
                    <input type="text" value={version} onChange={e => setVersion(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" placeholder="Ex: v1.0" />
                 </div>
                 <div>
                    <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Selo / Título</label>
                    <input type="text" value={badgeTitle} onChange={e => setBadgeTitle(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50" placeholder="Ex: Tester Inicial" />
                 </div>
               </div>
               <div>
                  <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Mensagem / Relato</label>
                  <textarea value={message} onChange={e => setMessage(e.target.value)} rows={3} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50 resize-none" placeholder="O que o tester relatou..." />
               </div>
            </div>
            <div className="p-5 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-[var(--color-surface-hover)]">
               <button onClick={handleCloseModal} className="px-4 py-2 text-[14px] font-medium text-white bg-transparent hover:bg-[var(--color-border)] rounded-xl transition-colors">Cancelar</button>
               <button onClick={handleSave} disabled={!name} className="px-4 py-2 text-[14px] font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-colors">
                 {editingTesterId ? 'Salvar Alterações' : 'Adicionar Tester'}
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
