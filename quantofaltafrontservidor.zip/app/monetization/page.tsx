'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/Card';
import { KeyRound, TrendingUp, Users, Plus, X, Copy, CheckCircle2 } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/Table';

const initialTokens = [
  { id: 'tok_h8f7x2', label: 'tok_***7x2', type: 'Lifetime', status: 'used', date: 'Hoje, 10:00', user: 'dev_8f29ea1' },
  { id: 'tok_k9jb49', label: 'tok_***b49', type: 'Anual', status: 'pending', date: 'Ontem, 16:30', user: '-' },
];

export default function MonetizationPage() {
  const [tokens, setTokens] = useState(initialTokens);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTokenPlan, setNewTokenPlan] = useState('Anual');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  const handleGenerate = () => {
    const randomHash = Math.random().toString(36).substring(2, 8);
    const newToken = {
      id: `tok_${randomHash}`,
      label: `tok_***${randomHash.substring(randomHash.length - 3)}`,
      type: newTokenPlan,
      status: 'pending',
      date: 'Agora mesmo',
      user: '-',
      isNew: true
    };
    setTokens(v => [newToken, ...v]);
    setIsModalOpen(false);
  };

  const handleCopy = (id: string) => {
    setCopiedToken(id);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const pendingCount = tokens.filter(t => t.status === 'pending').length;

  return (
    <div className="space-y-6 pb-12 relative">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Monetização e Tokens Premium</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Gere tokens seguros de ativação premium e monitore receita.</p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white border border-emerald-400/50 px-4 py-2 rounded-xl transition-colors text-[14px] font-medium">
          <KeyRound className="h-4 w-4" />
          Gerar Novo Token
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Usuários Premium</p>
              <Users className="h-4 w-4 text-purple-400" />
            </div>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">1,402</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Taxa de Conversão</p>
              <TrendingUp className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">5.7%</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Tokens Pendentes</p>
              <KeyRound className="h-4 w-4 text-amber-400" />
            </div>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">{23 + pendingCount}</p>
          </CardContent>
        </Card>
      </div>

      <div className="bg-[var(--color-surface-hover)] rounded-2xl overflow-hidden border border-[var(--color-border)]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Referência</TableHead>
              <TableHead>Tipo de Plano</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Gerado em</TableHead>
              <TableHead>Ativado por (Worker ID)</TableHead>
              <TableHead className="text-right">Ação</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tokens.map((token: any) => (
              <TableRow key={token.id} className={token.isNew ? "bg-emerald-500/5" : ""}>
                <TableCell>
                  <span className="font-mono text-[14px] text-white flex items-center gap-2">
                    {token.isNew ? token.id : token.label}
                    {token.isNew && <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded-full uppercase tracking-wider font-bold">Novo</span>}
                  </span>
                </TableCell>
                <TableCell className="text-[13px] text-white font-medium">{token.type}</TableCell>
                <TableCell>
                  {token.status === 'used' ? (
                    <Badge variant="success" className="px-2 py-0.5">Utilizado</Badge>
                  ) : (
                    <Badge variant="warning" className="px-2 py-0.5">Pendente</Badge>
                  )}
                </TableCell>
                <TableCell className="text-[13px] text-[var(--color-primary-muted)]">{token.date}</TableCell>
                <TableCell className="font-mono text-[12px] text-[var(--color-primary-muted)]">{token.user}</TableCell>
                <TableCell className="text-right">
                  <button 
                    onClick={() => handleCopy(token.id)} 
                    disabled={token.status === 'used'}
                    className={`text-[13px] font-medium transition-colors ml-auto flex items-center gap-1.5 justify-end ${
                      token.status === 'used' ? 'text-[var(--color-primary-muted)] opacity-50 cursor-not-allowed' :
                      copiedToken === token.id ? 'text-emerald-400' : 'text-purple-400 hover:text-purple-300'
                    }`}
                  >
                    {copiedToken === token.id ? (
                      <><CheckCircle2 className="w-3.5 h-3.5" /> Copiado</>
                    ) : (
                      <><Copy className="w-3.5 h-3.5" /> Copiar</>
                    )}
                  </button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] shadow-2xl rounded-2xl w-full max-w-sm overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-[var(--color-border)]">
               <h3 className="text-lg font-bold text-white flex items-center gap-2">
                 <KeyRound className="w-5 h-5 text-emerald-400" /> Gerar Token
               </h3>
               <button onClick={() => setIsModalOpen(false)} className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <div className="p-5 flex-1 relative custom-scrollbar space-y-4">
               <div>
                  <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">Plano de Acesso</label>
                  <select value={newTokenPlan} onChange={e => setNewTokenPlan(e.target.value)} className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2.5 text-white text-[14px] focus:outline-none focus:border-emerald-500/50 appearance-none">
                    <option value="Lifetime">Lifetime (Vitalício)</option>
                    <option value="Anual">Anual</option>
                    <option value="Mensal">Mensal</option>
                  </select>
               </div>
               <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3">
                  <p className="text-[11px] text-amber-500 font-medium">Atenção</p>
                  <p className="text-[12px] text-amber-400/80 mt-1">O token será exibido completamente apenas uma vez (agora). Copie-o imediatamente.</p>
               </div>
            </div>

            <div className="p-5 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-[var(--color-surface-hover)]">
               <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-[14px] font-medium text-white bg-transparent hover:bg-[var(--color-border)] rounded-xl transition-colors">Cancelar</button>
               <button onClick={handleGenerate} className="px-4 py-2 text-[14px] font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors">
                 Gerar Agora
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
