'use client';

import { useState } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/Table';
import { Badge } from '@/components/ui/Badge';
import { Star, MessageSquareText, X, Reply } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/Card';

const initialFeedbacks = [
  { id: 'fb_1', rating: 5, user: 'Usuário Anônimo (dev_8f2)', text: 'App muito bom, ajudou bastante a organizar.', date: '10 min atrás', status: 'new', category: 'elogio', version: '1.2.0' },
  { id: 'fb_2', rating: 2, user: 'Usuário Anônimo (dev_9f4)', text: 'Depois da última atualização começou a travar na tela inicial.', date: '1 hora atrás', status: 'investigating', category: 'bug', version: '1.1.9' },
  { id: 'fb_3', rating: 4, user: 'Usuário Anônimo (dev_1a7)', text: 'Poderia ter um modo noturno amoled.', date: 'Ontem', status: 'resolved', category: 'sugestão', version: '1.1.8' },
];

export default function FeedbacksPage() {
  const [feedbacks, setFeedbacks] = useState(initialFeedbacks);
  const [isReplyModalOpen, setIsReplyModalOpen] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState<typeof initialFeedbacks[0] | null>(null);
  const [replyText, setReplyText] = useState('');

  const openReplyModal = (fb: typeof initialFeedbacks[0]) => {
    setSelectedFeedback(fb);
    setReplyText('');
    setIsReplyModalOpen(true);
  };

  const closeReplyModal = () => {
    setIsReplyModalOpen(false);
    setSelectedFeedback(null);
  };

  const submitReply = () => {
    if (selectedFeedback) {
      setFeedbacks(v => v.map(f => f.id === selectedFeedback.id ? { ...f, status: 'resolved' } : f));
    }
    closeReplyModal();
  };

  const averageRating = (feedbacks.reduce((acc, f) => acc + f.rating, 0) / feedbacks.length).toFixed(1);

  return (
    <div className="space-y-6 pb-12 relative">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-bold tracking-tight text-white m-0 p-0 leading-none">Feedbacks</h1>
          <p className="text-[14px] text-[var(--color-primary-muted)] mt-2">Acompanhe as avaliações e comentários recebidos.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Média Geral</p>
              <Star className="h-4 w-4 text-emerald-400 fill-emerald-400" />
            </div>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">{averageRating}</p>
            <p className="text-[12px] text-emerald-400 mt-1.5 font-medium">+0.2 vs mês anterior</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-5 flex flex-col justify-center">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold text-[var(--color-primary-muted)] tracking-wider uppercase mb-1 drop-shadow-sm">Total de Avaliações</p>
              <MessageSquareText className="h-4 w-4 text-purple-400" />
            </div>
            <p className="text-4xl font-bold text-white mt-1 drop-shadow-sm">{feedbacks.length}</p>
            <p className="text-[12px] text-[var(--color-primary-muted)] mt-1.5 font-medium">32 nos últimos 7 dias</p>
          </CardContent>
        </Card>
      </div>

      <div className="bg-[var(--color-surface-hover)] rounded-2xl overflow-hidden border border-[var(--color-border)]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nota</TableHead>
              <TableHead>Comentário</TableHead>
              <TableHead>Versão</TableHead>
              <TableHead>Data</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ação</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {feedbacks.map((fb) => (
              <TableRow key={fb.id}>
                <TableCell>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-[14px] text-white">{fb.rating}</span>
                    <Star className={`h-3.5 w-3.5 ${fb.rating >= 4 ? 'text-emerald-400 fill-emerald-400' : fb.rating === 3 ? 'text-amber-400 fill-amber-400' : 'text-red-400 fill-red-400'}`} />
                  </div>
                </TableCell>
                <TableCell className="max-w-[400px]">
                  <p className="text-[14px] truncate text-white">{fb.text}</p>
                  <p className="text-[12px] text-[var(--color-primary-muted)] mt-0.5">{fb.user} • {fb.category}</p>
                </TableCell>
                <TableCell className="font-mono text-[13px] text-[var(--color-primary-muted)]">v{fb.version}</TableCell>
                <TableCell className="text-[13px] text-[var(--color-primary-muted)]">{fb.date}</TableCell>
                <TableCell>
                  {fb.status === 'new' && <Badge variant="default" className="bg-purple-500/20 text-purple-400 border border-purple-500/20">Novo</Badge>}
                  {fb.status === 'investigating' && <Badge variant="warning">Investigando</Badge>}
                  {fb.status === 'resolved' && <Badge variant="success">Resolvido</Badge>}
                </TableCell>
                <TableCell className="text-right">
                  {fb.status !== 'resolved' ? (
                    <button onClick={() => openReplyModal(fb)} className="flex items-center justify-end gap-1.5 text-[13px] font-medium text-purple-400 hover:text-purple-300 transition-colors ml-auto">
                      <Reply className="w-3.5 h-3.5" />
                      Responder
                    </button>
                  ) : (
                    <button onClick={() => openReplyModal(fb)} className="flex items-center justify-end gap-1.5 text-[13px] font-medium text-[var(--color-primary-muted)] hover:text-white transition-colors ml-auto">
                      Ver Resposta
                    </button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {isReplyModalOpen && selectedFeedback && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-[var(--color-surface)] border border-[var(--color-border)] shadow-2xl rounded-2xl w-full max-w-md overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-[var(--color-border)]">
               <h3 className="text-lg font-bold text-white flex items-center gap-2">
                 <Reply className="w-5 h-5 text-purple-400" /> {selectedFeedback.status === 'resolved' ? 'Detalhes do Feedback' : 'Responder Feedback'}
               </h3>
               <button onClick={closeReplyModal} className="text-[var(--color-primary-muted)] hover:text-white transition-colors">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <div className="p-5 flex-1 relative max-h-[80vh] overflow-y-auto custom-scrollbar">
              <div className="space-y-4">
                <div className="bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[13px] font-medium text-white">{selectedFeedback.user}</span>
                    <span className="text-[12px] text-[var(--color-primary-muted)]">{selectedFeedback.date}</span>
                  </div>
                  <p className="text-[14px] text-[var(--color-primary-muted)] italic">"{selectedFeedback.text}"</p>
                </div>
                
                <div>
                   <label className="block text-[13px] font-medium text-[var(--color-primary-muted)] mb-1.5">{selectedFeedback.status === 'resolved' ? 'Resposta Enviada' : 'Sua Resposta'}</label>
                   <textarea 
                     value={selectedFeedback.status === 'resolved' ? 'Agradecemos o feedback! A equipe já está trabalhando nisso.' : replyText} 
                     onChange={(e) => setReplyText(e.target.value)} 
                     rows={4} 
                     disabled={selectedFeedback.status === 'resolved'}
                     className="w-full bg-[var(--color-surface-hover)] border border-[var(--color-border)] rounded-xl px-3 py-2 text-white text-[14px] focus:outline-none focus:border-purple-500/50 resize-none disabled:opacity-75 disabled:cursor-not-allowed" 
                     placeholder="Escreva sua resposta e resolução para o usuário..." 
                     autoFocus={selectedFeedback.status !== 'resolved'}
                   />
                </div>
              </div>
            </div>

            <div className="p-5 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-[var(--color-surface-hover)]">
               <button onClick={closeReplyModal} className="px-4 py-2 text-[14px] font-medium text-white bg-transparent hover:bg-[var(--color-border)] rounded-xl transition-colors">Fechar</button>
               {selectedFeedback.status !== 'resolved' && (
                 <button onClick={submitReply} disabled={!replyText} className="px-4 py-2 text-[14px] font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-colors">
                   Enviar e Resolver
                 </button>
               )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
