/** Typed API client for the Quanto Falta? admin backend */
const BASE = (import.meta as any).env.DEV ? 'http://localhost:8787' : '';

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(BASE + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...options?.headers },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Network error' }));
    throw new ApiError(res.status, (err as any).error ?? 'Unknown error', (err as any).code);
  }
  return res.json() as Promise<T>;
}

export class ApiError extends Error {
  constructor(public status: number, message: string, public code?: string) {
    super(message);
  }
}


// ── Metrics ───────────────────────────────────────────────
export const metrics = {
  overview: (days = 30) => request<any>(`/admin/metrics/overview?days=${days}`),
  events: (days = 7, event?: string) =>
    request<any>(`/admin/metrics/events?days=${days}${event ? `&event=${event}` : ''}`),
  performance: (days = 14) => request<any>(`/admin/metrics/performance?days=${days}`),
};

// ── Versions ──────────────────────────────────────────────
export const versions = {
  list: (params?: { channel?: string; status?: string; limit?: number }) => {
    const q = new URLSearchParams(params as any).toString();
    return request<any>(`/admin/versions${q ? '?' + q : ''}`);
  },
  create: (data: any) =>
    request<any>('/admin/versions', { method: 'POST', body: JSON.stringify(data) }),
  update: (versionCode: number, data: any) =>
    request<any>(`/admin/versions/${versionCode}`, { method: 'PATCH', body: JSON.stringify(data) }),
  uploadRelease: (formData: FormData) => {
    // Note: don't set Content-Type header when sending FormData, fetch will set it with boundary automatically
    return fetch(BASE + '/admin/versions/github-release', {
      method: 'POST',
      body: formData,
      credentials: 'include',
    }).then(async res => {
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Upload failed' }));
        throw new ApiError(res.status, (err as any).error ?? 'Upload error', (err as any).code);
      }
      return res.json() as Promise<any>;
    });
  },
};

// ── Feedback ──────────────────────────────────────────────
export const feedback = {
  list: (params?: Record<string, string>) => {
    const q = new URLSearchParams(params).toString();
    return request<any>(`/admin/feedback${q ? '?' + q : ''}`);
  },
  update: (id: string, data: any) =>
    request<any>(`/admin/feedback/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  stats: () => request<any>('/admin/feedback/stats'),
};

// ── Settings ──────────────────────────────────────────────
export const settings = {
  list: () => request<any>('/admin/settings'),
  update: (key: string, value: string) =>
    request<any>(`/admin/settings/${key}`, { method: 'PUT', body: JSON.stringify({ value }) }),
};

// ── Testers ───────────────────────────────────────────────
export const testers = {
  list: () => request<any>('/admin/testers'),
  create: (data: any) => request<any>('/admin/testers', { method: 'POST', body: JSON.stringify(data) }),
  update: (id: string, data: any) => request<any>(`/admin/testers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  remove: (id: string) => request<any>(`/admin/testers/${id}`, { method: 'DELETE' }),
};

// ── App Config ────────────────────────────────────────────
export const config = {
  get: () => request<any>('/api/v1/config', { credentials: 'omit' }),
};

// ── Monetization ──────────────────────────────────────────
export const monetization = {
  metrics: () => request<any>('/admin/monetization/metrics'),
  purchases: () => request<any>('/admin/monetization/purchases'),
  users: () => request<any>('/admin/monetization/users'),
  codes: () => request<any>('/admin/monetization/codes'),
  createCode: (data: any) => request<any>('/admin/monetization/codes', { method: 'POST', body: JSON.stringify(data) }),
};
