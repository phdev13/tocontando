import { Hono } from 'hono';
import type { Env } from '../types';

export const syncRoutes = new Hono<{ Bindings: Env }>();

syncRoutes.post('/sync/backup', async (c) => {
  try {
    const { installation_id, data } = await c.req.json();
    if (!installation_id || !data) {
      return c.json({ error: 'Missing parameters' }, 400);
    }

    const db = c.env.DB;
    await db.prepare(
      `INSERT INTO user_backups (installation_id, data)
       VALUES (?, ?)
       ON CONFLICT(installation_id) DO UPDATE SET data = excluded.data, updated_at = unixepoch() * 1000`
    ).bind(installation_id, JSON.stringify(data)).run();

    return c.json({ success: true });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});

syncRoutes.get('/sync/restore', async (c) => {
  try {
    const installation_id = c.req.query('installation_id');
    if (!installation_id) {
      return c.json({ error: 'Missing installation_id' }, 400);
    }

    const db = c.env.DB;
    const row = await db.prepare(
      `SELECT data, updated_at FROM user_backups WHERE installation_id = ?`
    ).bind(installation_id).first<{ data: string; updated_at: number }>();

    if (!row) {
      return c.json({ error: 'No backup found' }, 404);
    }

    return c.json({ success: true, data: JSON.parse(row.data), updated_at: row.updated_at });
  } catch (err: any) {
    return c.json({ error: err.message }, 500);
  }
});
