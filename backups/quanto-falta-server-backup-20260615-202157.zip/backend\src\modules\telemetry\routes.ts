import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../../types';
import { fail, ok } from '../../contracts/apiResponse';

export const telemetryAppRoutes = new Hono<{ Bindings: Env }>();

const APPROVED_SOURCES = ['android', 'website', 'admin', 'backend'] as const;
const APPROVED_EVENTS = new Set([
  'app_opened', 'session_started', 'session_ended', 'screen_viewed',
  'event_created', 'event_edited', 'event_deleted',
  'feedback_submitted', 'ota_check_completed', 'ota_update_available',
  'premium_status_checked', 'premium_token_activated',
]);
const APPROVED_PROPERTY_KEYS = new Set([
  'screen', 'session_id', 'duration_ms', 'version_code', 'version_name',
  'android_version', 'theme', 'event_type', 'is_premium', 'ota_version_code',
  'ota_channel', 'ota_mandatory', 'feedback_category', 'error_type',
]);

const TelemetrySchema = z.object({
  installationId: z.string().uuid(),
  source: z.enum(APPROVED_SOURCES).default('android'),
  events: z.array(z.object({
    event: z.string().max(64),
    timestamp: z.string().datetime().optional(),
    properties: z.record(z.union([z.string().max(256), z.number(), z.boolean()])).optional(),
  })).max(100),
});

telemetryAppRoutes.post('/telemetry', async (c) => {
  const body = await c.req.json().catch(() => null);
  const parsed = TelemetrySchema.safeParse(body);
  if (!parsed.success) return fail(c, 'INVALID_REQUEST', 'Payload de telemetria invalido.', 400);

  const validEvents = parsed.data.events
    .filter((event) => APPROVED_EVENTS.has(event.event))
    .map((event) => ({
      event: event.event,
      timestamp: event.timestamp ? Date.parse(event.timestamp) : Date.now(),
      properties: sanitizeProperties(event.properties ?? {}),
    }));

  if (validEvents.length > 0) {
    const statements = validEvents.map((event) =>
      c.env.DB.prepare(
        `INSERT INTO analytics_events(installation_id, event_name, properties, version_code, session_id, created_at)
         VALUES(?, ?, ?, ?, ?, ?)`
      ).bind(
        parsed.data.installationId,
        event.event,
        JSON.stringify({ source: parsed.data.source, ...event.properties }),
        typeof event.properties.version_code === 'number' ? event.properties.version_code : null,
        typeof event.properties.session_id === 'string' ? event.properties.session_id : null,
        event.timestamp,
      )
    );

    c.executionCtx.waitUntil(c.env.DB.batch(statements).catch(() => undefined));
  }

  return ok(c, { accepted: validEvents.length });
});

function sanitizeProperties(props: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(props)
      .filter(([key]) => APPROVED_PROPERTY_KEYS.has(key))
      .slice(0, 20),
  );
}
